// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.swing.JLabel;

public class Game extends Thread
{
    public boolean running;
    private Board board1;
    private Board board2;
    private JLabel status;
    private Chessbot app;
    private int timerMs;
    private long startedOn;
    
    public void logDebug(final String s) {
        if (!this.getApp().isDebugEnabled()) {
            this.app.logDebug(s);
            return;
        }
        this.app.log(s);
    }
    
    public void log(final String s) {
        this.app.log(s);
    }
    
    public void status(final String s) {
        this.status.setText(s);
    }
    
    public Game(final Board Board1, final Chessbot app, final JLabel Status) {
        this.running = false;
        (this.board1 = Board1).setGame(this);
        this.app = app;
        this.status = Status;
    }
    
    public void setBoard2(final Board board2) {
        (this.board2 = board2).setGame(this);
        this.board1.setMirror(board2);
        board2.setMirror(this.board1);
    }
    
    @Override
    public void run() {
        while (true) {
            final long l0 = System.currentTimeMillis();
            Screen.checkpoint();
            try {
                Thread.sleep(60L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                if (this.running && Screen.isOnStopSpot()) {
                    this.app.stopGame();
                }
                else if (!this.running && Screen.isOnStartSpot()) {
                    this.app.startGame();
                }
                else if (Screen.needsPause()) {
                    Thread.sleep(1000L);
                }
                else {
                    if (!this.running) {
                        continue;
                    }
                    if (this.app.isDeadMouseEnabled() && System.currentTimeMillis() > this.startedOn + 2000L) {
                        this.board1.livingMouse();
                    }
                    final boolean ourTurn = this.board2.isThinking();
                    this.board1.ensureInitialized();
                    this.board2.ensureInitialized();
                    this.board1.update();
                    this.board2.update();
                    if (ourTurn) {
                        this.timerMs -= (int)(System.currentTimeMillis() - l0);
                    }
                    if (!this.running || !this.isTimerEnabled()) {
                        continue;
                    }
                    this.app.updateClock(this.timerMs / 1000);
                }
            }
            catch (Exception e2) {
                this.logDebug("Exception: " + e2.getMessage());
                final StringWriter out = new StringWriter();
                final PrintWriter out2 = new PrintWriter(out);
                e2.printStackTrace(out2);
                out2.flush();
                this.logDebug(out.toString());
            }
        }
    }
    
    public void manualTurn() {
        ((UIBoard)this.board1).setForceMovement(true);
        this.board1.update();
        this.board2.update();
    }
    
    public void resetBoards() {
        this.board1.reset();
        this.board2.reset();
    }
    
    public void dumpBoards() {
        this.board1.dumpBoard();
        this.board2.dumpBoard();
    }
    
    public void setRunning(final boolean on) {
        if (on) {
            this.startedOn = System.currentTimeMillis();
        }
        this.running = on;
    }
    
    public boolean isRunning() {
        return this.running;
    }
    
    public void appFocus() {
    }
    
    public int getDelay() {
        return this.app.getDelay();
    }
    
    public boolean isAnimationEnabled(final Board board) {
        return this.app.isAnimationEnabled(board);
    }
    
    public boolean isAnimationTriggerEnabled(final Board board) {
        return this.app.isAnimationTriggerEnabled(board);
    }
    
    public int getAnimationTriggerTimer(final Board board) {
        return this.app.getAnimationTriggerTimer(board);
    }
    
    public Chessbot getApp() {
        return this.app;
    }
    
    public void setTimerSeconds(final int timerSeconds) {
        this.timerMs = timerSeconds * 1000;
    }
    
    public int getTimerMs() {
        return this.timerMs;
    }
    
    public boolean isTimerEnabled() {
        return this.app.isTimerEnabled();
    }
    
    public void setBestMove(final int idx, final String move, final String extra) {
        this.app.setBestMove(idx, move, extra);
    }
    
    public void clearBestMoves() {
        this.app.clearBestMoves();
    }
    
    public void setPonder(final String ponder) {
        this.app.setPonder(ponder);
    }
    
    public String getStartPos() {
        return this.app.getStartPos();
    }
    
    public boolean isManualMode() {
        return this.app.isManualMode();
    }
}
