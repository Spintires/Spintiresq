// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.engine;

import javax.swing.SpinnerModel;
import com.malkav.chessbot.Settings;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComponent;

public class EngineOption
{
    private String name;
    private OptionType type;
    private String defaultValue;
    private int min;
    private int max;
    private String value;
    private JComponent component;
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public OptionType getType() {
        return this.type;
    }
    
    public void setType(final OptionType type) {
        this.type = type;
    }
    
    public void setType(final String type) {
        this.type = OptionType.valueOf(type);
    }
    
    public String getDefaultValue() {
        return this.defaultValue;
    }
    
    public void setDefaultValue(final String defaultValue) {
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }
    
    public int getMin() {
        return this.min;
    }
    
    public void setMin(final int min) {
        this.min = min;
    }
    
    public int getMax() {
        return this.max;
    }
    
    public void setMax(final int max) {
        this.max = max;
    }
    
    public String getValue() {
        return this.value;
    }
    
    public void setValue(final String value) {
        this.value = value;
    }
    
    public int getValueAsInt() {
        if (this.value == null) {
            return 0;
        }
        return Integer.parseInt(this.value);
    }
    
    public JComponent getComponent() {
        return this.component;
    }
    
    public void setComponent(final JComponent component) {
        this.component = component;
        this.updateUI();
    }
    
    public void updateUI() {
        if (this.component == null) {
            return;
        }
        if (this.type == OptionType.check) {
            ((JCheckBox)this.component).setSelected("true".equals(this.value));
        }
        else if (this.type == OptionType.string) {
            ((JTextField)this.component).setText(this.value);
        }
        else if (this.type != OptionType.button && this.type == OptionType.spin) {
            if (this.value == null) {
                this.value = this.defaultValue;
            }
            if (this.value != null) {
                ((JSpinner)this.component).setValue(Integer.parseInt(this.value));
            }
        }
    }
    
    public void updateEngine(final Engine engine) {
        if (this.type == OptionType.check) {
            if (this.component != null) {
                final JCheckBox chk = (JCheckBox)this.component;
                this.value = (chk.isSelected() ? "true" : "false");
            }
            engine.send("setoption name " + this.getName() + " value " + this.value);
            Settings.set(engine.getEngineOptionKey(this), this.value);
        }
        else if (this.type == OptionType.string) {
            if (this.component != null) {
                final JTextField txt = (JTextField)this.component;
                this.value = txt.getText();
            }
            engine.send("setoption name " + this.getName() + " value " + this.value);
            Settings.set(engine.getEngineOptionKey(this), this.value);
        }
        else if (this.type != OptionType.button && this.type == OptionType.spin) {
            if (this.component != null) {
                final JSpinner spinner = (JSpinner)this.component;
                final SpinnerModel model = spinner.getModel();
                this.value = String.valueOf(model.getValue());
            }
            engine.send("setoption name " + this.getName() + " value " + this.value);
            Settings.set(engine.getEngineOptionKey(this), this.value);
        }
    }
}
