// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.engine;

public enum OptionType
{
    spin, 
    check, 
    button, 
    string, 
    combo;
}
