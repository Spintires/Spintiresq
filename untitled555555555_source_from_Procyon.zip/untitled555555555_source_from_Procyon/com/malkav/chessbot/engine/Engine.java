// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.engine;

import java.util.HashSet;
import java.io.File;
import com.malkav.chessbot.Settings;
import java.io.IOException;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.List;
import java.io.PrintWriter;
import java.io.BufferedReader;
import com.malkav.chessbot.Game;

public class Engine
{
    private boolean initialized;
    private String path;
    private Game game;
    private String errorMsg;
    private String lastInfo;
    private Process proc;
    private BufferedReader in;
    private BufferedReader err;
    private PrintWriter out;
    private List<String> lines;
    private Object lineLock;
    private List<EngineOption> options;
    private static Set<String> validOptions;
    
    public static void main(final String[] args) throws Exception {
        final Engine eng = new Engine("C:\\freelancing\\Chessbot\\arena_3.0\\engines\\Hermann\\Hermann_2.6_64.exe");
        eng.init();
        eng.send("ucinewgame");
        eng.send("position startpos");
        eng.send("go movetime 2000");
        Thread.sleep(2000L);
        eng.send("stop");
        dump(eng.waitFor("bestmove"));
        eng.send("position startpos e2de e7e5");
        eng.send("go movetime 2000");
        Thread.sleep(2000L);
        dump(eng.sendSync("stop"));
        while (true) {
            System.out.println(eng.getNextResponse(true));
        }
    }
    
    private static void dump(final List<String> lines) {
        for (final String line : lines) {
            if (line.startsWith("info ")) {
                continue;
            }
            System.out.println(line);
        }
    }
    
    public Engine(final String path) {
        this.lines = Collections.synchronizedList(new ArrayList<String>());
        this.lineLock = new Object();
        this.options = new ArrayList<EngineOption>();
        this.path = path;
        try {
            this.proc = new ProcessBuilder(new String[] { path }).start();
            this.in = new BufferedReader(new InputStreamReader(this.proc.getInputStream()));
            this.err = new BufferedReader(new InputStreamReader(this.proc.getErrorStream()));
            this.out = new PrintWriter(new OutputStreamWriter(this.proc.getOutputStream()));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    String line = null;
                    while ((line = Engine.this.in.readLine()) != null) {
                        if (!line.startsWith("info")) {
                            if (Engine.this.game != null) {
                                Engine.this.game.logDebug("<<" + line);
                            }
                            System.out.println("<<" + line);
                        }
                        if (line.startsWith("info")) {
                            Engine.access$2(Engine.this, line);
                        }
                        if (line.startsWith("ERROR")) {
                            Engine.access$3(Engine.this, line);
                        }
                        Engine.this.lines.add(line);
                        final Object object = Engine.this.lineLock;
                        synchronized (object) {
                            Engine.this.lineLock.notifyAll();
                        }
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();
        t = new Thread() {
            @Override
            public void run() {
                try {
                    String line = null;
                    while ((line = Engine.this.err.readLine()) != null) {
                        System.err.println(line);
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();
    }
    
    public String getError() {
        return this.errorMsg;
    }
    
    public void clearError() {
        this.errorMsg = null;
    }
    
    public void init() {
        this.initialized = true;
        this.sendSync("uci");
        final List<String> lines = this.waitFor("uciok");
        for (final String line : lines) {
            if (!line.startsWith("option")) {
                continue;
            }
            this.processOption(line);
        }
    }
    
    private void processOption(final String line) {
        System.out.println("process option " + line);
        final String[] x = line.split(" ");
        if ("option".equals(x[0])) {
            final EngineOption option = new EngineOption();
            int i = 1;
            while (i < x.length) {
                final String key;
                if ("name".equals(key = x[i++])) {
                    String name;
                    for (name = x[i++]; !Engine.validOptions.contains(x[i]); name = String.valueOf(name) + " " + x[i++]) {}
                    option.setName(name);
                }
                else if ("type".equals(key)) {
                    option.setType(x[i++]);
                }
                else if ("default".equals(key)) {
                    if (i + 1 >= x.length) {
                        continue;
                    }
                    option.setDefaultValue(x[i++]);
                }
                else if ("min".equals(key)) {
                    option.setMin(Integer.parseInt(x[i++]));
                }
                else if ("max".equals(key)) {
                    option.setMax(Integer.parseInt(x[i++]));
                }
                else {
                    System.err.println("Unknown parameter type: " + key + " on " + line);
                    ++i;
                }
            }
            this.options.add(option);
        }
    }
    
    public List<EngineOption> getOptions() {
        return this.options;
    }
    
    public List<String> sendSync(final String command) {
        this.send(command);
        final ArrayList<String> list = new ArrayList<String>();
        list.add(this.getNextResponse(true));
        String l = null;
        while ((l = this.getNextResponse(false)) != null) {
            list.add(l);
        }
        return list;
    }
    
    public List<String> waitFor(final String command) {
        final ArrayList<String> list = new ArrayList<String>();
        String l = null;
        while ((l = this.getNextResponse(true)) != null) {
            list.add(l);
            if (l.startsWith(command)) {
                break;
            }
        }
        return list;
    }
    
    public void send(final String command) {
        if (this.game != null) {
            this.game.logDebug(">>" + command);
        }
        System.out.println(">" + command);
        this.out.println(command);
        this.out.flush();
    }
    
    public String getNextResponse(final boolean wait) {
        while (this.lines.isEmpty()) {
            if (!wait) {
                return null;
            }
            final Object object = this.lineLock;
            synchronized (object) {
                try {
                    this.lineLock.wait(1000L);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                    return null;
                }
            }
        }
        final String line = this.lines.get(0);
        this.lines.remove(0);
        return line;
    }
    
    public void initIfNeeded() {
        if (!this.initialized) {
            this.init();
        }
    }
    
    public void loadLastOptions() {
        final String engineName = this.getEngineName();
        for (final EngineOption option : this.getOptions()) {
            final String key = "engine.options." + engineName + "." + option.getName();
            final String savedValue = Settings.get(key);
            if (savedValue == null) {
                continue;
            }
            option.setValue(savedValue);
            option.updateEngine(this);
        }
    }
    
    public String getPath() {
        return this.path;
    }
    
    public String getEngineName() {
        final int idx = this.path.lastIndexOf(File.separatorChar);
        return (idx != -1) ? this.path.substring(idx + 1) : this.path;
    }
    
    public String getEngineParentPath() {
        final int idx = this.path.lastIndexOf(File.separatorChar);
        return (idx != -1) ? this.path.substring(0, idx) : "";
    }
    
    public String getEngineOptionKey(final EngineOption option) {
        return "engine.options." + this.getEngineName() + "." + option.getName();
    }
    
    public String getLastInfo() {
        return this.lastInfo;
    }
    
    public void quit() {
        this.send("stop");
        this.send("quit");
        final Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000L);
                }
                catch (InterruptedException ex) {}
                Engine.this.proc.destroy();
            }
        };
        t.start();
    }
    
    public boolean isPonderEnabled() {
        for (final EngineOption option : this.getOptions()) {
            if (!"Ponder".equals(option.getName())) {
                continue;
            }
            return "true".equals(option.getValue());
        }
        return false;
    }
    
    public boolean is960Enabled() {
        for (final EngineOption option : this.getOptions()) {
            if (!"UCI_Chess960".equals(option.getName())) {
                continue;
            }
            return "true".equals(option.getValue());
        }
        return false;
    }
    
    public void setGame(final Game game) {
        this.game = game;
    }
    
    static void access$2(final Engine engine, final String string) {
        engine.lastInfo = string;
    }
    
    static void access$3(final Engine engine, final String string) {
        engine.errorMsg = string;
    }
    
    static {
        (Engine.validOptions = new HashSet<String>()).add("name");
        Engine.validOptions.add("type");
        Engine.validOptions.add("default");
        Engine.validOptions.add("min");
        Engine.validOptions.add("max");
    }
}
