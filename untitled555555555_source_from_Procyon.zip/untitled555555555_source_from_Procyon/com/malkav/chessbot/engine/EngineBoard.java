// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.engine;

import com.malkav.chessbot.Game;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import com.malkav.chessbot.book.abk.AbkBookReader;
import java.awt.EventQueue;
import com.malkav.chessbot.Settings;
import com.malkav.chessbot.book.BookMove;
import com.malkav.chessbot.UIBoard;
import java.util.Iterator;
import java.util.List;
import java.io.File;
import java.text.DecimalFormat;
import com.malkav.chessbot.book.Book;
import com.malkav.chessbot.Board;

public class EngineBoard extends Board
{
    private Engine engine;
    private StringBuilder gameHistory;
    private int moveTime;
    private int depth;
    private String ponder;
    private boolean firstMoveStarted;
    private boolean ignoreNextBestMove;
    private boolean useBook;
    private Book book;
    private static DecimalFormat FORMAT_CP;
    private File lastBookFile;
    
    public EngineBoard() {
        this.gameHistory = new StringBuilder();
        this.moveTime = 2000;
        this.depth = 5;
        this.firstMoveStarted = false;
        this.ignoreNextBestMove = false;
    }
    
    public void setEngine(final Engine engine) {
        final Engine old = this.engine;
        this.engine = engine;
        if (old != null) {
            old.quit();
        }
        if (this.engine != null) {
            this.engine.setGame(this.game);
        }
    }
    
    private static void dump(final List<String> lines) {
        for (final String line : lines) {
            if (line.startsWith("info ")) {
                continue;
            }
            System.out.println(line);
        }
    }
    
    @Override
    public void livingMouse() {
    }
    
    @Override
    public void ensureInitialized() {
        this.getEngine().initIfNeeded();
    }
    
    @Override
    public void update() {
        String line = null;
        while ((line = this.engine.getNextResponse(false)) != null) {
            System.out.println(".. " + line);
            final String[] command = line.split(" ");
            if (command.length <= 0) {
                continue;
            }
            this.game.logDebug("Processing " + command[0]);
            if (command[0].equals("bestmove")) {
                this.game.logDebug("Processing bestmove");
                if (this.ignoreNextBestMove) {
                    this.game.logDebug("Ignoring best move...");
                    this.ignoreNextBestMove = false;
                }
                else {
                    final String move = command[1];
                    final String m1 = move.substring(0, 2);
                    final String m2 = move.substring(2);
                    if (!this.game.isManualMode()) {
                        if (move.endsWith("q")) {
                            final String moveNoQ = move.substring(0, 4);
                            if (this.gameHistory.toString().endsWith(moveNoQ)) {
                                this.game.logDebug("Fixing opponent promotion!");
                                this.gameHistory.append("q");
                                this.engine.send("position " + this.getStartPos() + " moves" + this.gameHistory.toString());
                                this.engine.send("go movetime " + this.moveTime + " depth " + this.depth + this.getTimerString());
                                continue;
                            }
                        }
                        System.out.println("move " + m1 + m2);
                        this.gameHistory.append(" " + m1 + m2);
                        this.mirror.move(m1, m2);
                        if (command.length >= 4 && command[2].equals("ponder") && this.engine.isPonderEnabled() && !"(none)".equals(command[3]) && !"NULL".equals(command[3])) {
                            this.ponder = command[3];
                            this.gameHistory.append(" " + this.ponder);
                            this.engine.send("position " + this.getStartPos() + " moves" + this.gameHistory.toString());
                            this.engine.send("go ponder movetime " + this.moveTime + " depth " + this.depth + this.getTimerString());
                        }
                        else {
                            this.ponder = null;
                        }
                    }
                    this.game.setPonder(this.ponder);
                }
            }
            else {
                if (!command[0].equals("info")) {
                    continue;
                }
                String move = null;
                String move2 = null;
                String move3 = null;
                String score = "";
                String time = "";
                String depth = null;
                int pv = 1;
                for (int i = 1; i < command.length; ++i) {
                    if (command[i].equals("multipv")) {
                        pv = Integer.parseInt(command[++i]);
                    }
                    else if (command[i].equals("depth")) {
                        depth = command[++i];
                    }
                    else if (command[i].equals("score")) {
                        final String scoreType = command[++i];
                        score = command[++i];
                        if (scoreType.equals("cp")) {
                            final int is = Integer.parseInt(score);
                            score = EngineBoard.FORMAT_CP.format(is / 100.0);
                        }
                        else if (scoreType.equals("mate")) {
                            score = "M" + score;
                        }
                    }
                    else if (command[i].equals("time")) {
                        time = command[++i];
                    }
                    else if (command[i].equals("pv")) {
                        move = command[++i];
                        if (i < command.length - 1) {
                            move2 = command[++i];
                        }
                        if (i < command.length - 1) {
                            move3 = command[++i];
                        }
                    }
                }
                if (move == null) {
                    continue;
                }
                if (depth == null) {
                    continue;
                }
                String moves = move;
                if (move2 != null) {
                    moves = String.valueOf(moves) + " " + move2;
                }
                if (move3 != null) {
                    moves = String.valueOf(moves) + " " + move3;
                }
                this.game.setBestMove(pv, moves, "S:" + score + " D:" + depth + " T:" + time);
            }
        }
        final Boolean whiteOnTop;
        if (!this.firstMoveStarted && this.gameHistory.length() == 0 && this.mirror instanceof UIBoard && (whiteOnTop = ((UIBoard)this.mirror).isWhiteOnTop()) != null && !whiteOnTop) {
            this.doFirstMove();
        }
    }
    
    @Override
    public void reset() {
        if (this.engine != null) {
            this.engine.send("stop");
        }
        this.ignoreNextBestMove = false;
        this.firstMoveStarted = false;
        if (this.engine != null) {
            this.engine.send("ucinewgame");
            this.engine.send("position " + this.getStartPos());
            if (this.ponder != null) {
                this.engine.waitFor("bestmove");
            }
        }
        this.gameHistory = new StringBuilder();
        this.ponder = null;
        this.useBook = true;
    }
    
    @Override
    public void dumpBoard() {
    }
    
    @Override
    public void moveImpl(final int from, final int to, final int from2, final int to2) {
        this.move(this.chessIndexToNotation(from), this.chessIndexToNotation(to));
    }
    
    private boolean isWhiteOnTop() {
        final Boolean whiteOnTop = ((UIBoard)this.mirror).isWhiteOnTop();
        return whiteOnTop != null && whiteOnTop;
    }
    
    private String chessIndexToNotation(final int idx) {
        int col = idx % 8;
        int row = 7 - idx / 8;
        if (!this.isWhiteOnTop()) {
            col = 7 - col;
            row = 7 - row;
        }
        return String.valueOf((char)(97 + col)) + String.valueOf(row + 1);
    }
    
    @Override
    public void move(final String m1, final String m2) {
        final String move = String.valueOf(m1) + m2;
        this.move(move);
    }
    
    public void move(final String move) {
        this.game.clearBestMoves();
        this.game.setPonder(null);
        System.out.println(" Opp moved " + move);
        if (this.ponder != null) {
            final int idx = this.gameHistory.lastIndexOf(" ");
            this.gameHistory = this.gameHistory.delete(idx, this.gameHistory.length());
        }
        this.gameHistory.append(" " + move);
        if (this.ponder != null && this.ponder.equals(move)) {
            System.out.println("PONDER HIT!");
            this.engine.send("ponderhit");
        }
        else {
            if (this.ponder != null) {
                this.engine.send("stop");
                this.engine.waitFor("bestmove");
            }
            if (this.isUsingBook()) {
                if (this.bookMove()) {
                    return;
                }
                this.game.logDebug("Can't find book move going back to engine!");
                this.useBook = false;
            }
            this.engine.send("position " + this.getStartPos() + " moves" + this.gameHistory.toString());
            this.engine.send("go movetime " + this.moveTime + " depth " + this.depth + this.getTimerString());
        }
        try {
            Thread.sleep(20L);
        }
        catch (InterruptedException ex) {}
        final String err;
        final int idx2;
        final int idx3;
        final String move2;
        if (this.engine.getError() != null && (err = this.engine.getError()).startsWith("ERROR: invalid move") && ((move2 = err.substring((idx2 = err.indexOf(60)) + 1, idx3 = err.indexOf(62))).endsWith("1") || move2.endsWith("8")) && this.gameHistory.toString().endsWith(move2)) {
            this.ignoreNextBestMove = true;
            this.game.logDebug("Detected promotion!");
            this.gameHistory.append("q");
            this.engine.send("position " + this.getStartPos() + " moves" + this.gameHistory.toString());
            this.engine.send("go movetime " + this.moveTime + " depth " + this.depth + this.getTimerString());
        }
    }
    
    public boolean isUsingBook() {
        return this.book != null && this.useBook && this.game.getApp().isUseBook();
    }
    
    private boolean bookMove() {
        final BookMove bookMove = this.book.pickNextMove(this.gameHistory.toString());
        if (bookMove != null) {
            final String move = bookMove.getNotation();
            final String m1 = move.substring(0, 2);
            final String m2 = move.substring(2);
            this.game.setBestMove(1, move, "Book");
            this.game.logDebug("Book move: " + m1 + "->" + m2);
            this.gameHistory.append(" " + m1 + m2);
            this.mirror.move(m1, m2);
            this.ponder = null;
            return true;
        }
        return false;
    }
    
    private String getStartPos() {
        if (!this.engine.is960Enabled()) {
            return "startpos";
        }
        String pos = this.game.getStartPos();
        if (pos == null) {
            return "startpos";
        }
        if (this.isWhiteOnTop()) {
            String ipos = "";
            for (int i = pos.length() - 1; i >= 0; --i) {
                ipos = String.valueOf(ipos) + pos.charAt(i);
            }
            pos = ipos;
        }
        return this.toFen(pos);
    }
    
    private String toFen(final String pos) {
        return "fen " + pos.toLowerCase() + "/pppppppp/8/8/8/8/PPPPPPPP/" + pos.toUpperCase() + " w KQkq - 0 1";
    }
    
    public void doFirstMove() {
        this.game.clearBestMoves();
        if (!this.isUsingBook() || !this.bookMove()) {
            this.engine.send("go movetime " + this.moveTime + " depth " + this.depth + this.getTimerString());
        }
        this.firstMoveStarted = true;
    }
    
    private String getTimerString() {
        if (this.game.isTimerEnabled()) {
            return " wtime " + this.game.getTimerMs() + " btime " + this.game.getTimerMs();
        }
        return "";
    }
    
    public Engine getEngine() {
        final String path;
        if (this.engine == null && (path = Settings.get("engine.enginePath")) != null) {
            (this.engine = new Engine(path)).init();
            this.engine.loadLastOptions();
            this.engine.setGame(this.game);
        }
        return this.engine;
    }
    
    public int getMoveTime() {
        return this.moveTime;
    }
    
    public void setMoveTime(final int moveTime) {
        this.moveTime = moveTime;
    }
    
    public int getDepth() {
        return this.depth;
    }
    
    public void setDepth(final int depth) {
        this.depth = depth;
    }
    
    public void loadBook(final File file) {
        if (file != null && this.lastBookFile != null && file.equals(this.lastBookFile)) {
            return;
        }
        try {
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    EngineBoard.this.game.log("Loading Book " + file.getName() + "...");
                }
            });
            final AbkBookReader bookReader = new AbkBookReader();
            this.book = bookReader.read(new BufferedInputStream(new FileInputStream(file)));
            this.useBook = true;
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    EngineBoard.this.game.log("Book " + file.getName() + " Loaded");
                }
            });
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public Book getBook() {
        return this.book;
    }
    
    static {
        EngineBoard.FORMAT_CP = new DecimalFormat("0.00");
    }
}
