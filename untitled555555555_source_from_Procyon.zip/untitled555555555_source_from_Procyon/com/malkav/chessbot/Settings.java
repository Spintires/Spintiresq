// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.Properties;

public class Settings
{
    private static Properties properties;
    
    private static File getDefaultFile() {
        return new File(String.valueOf(System.getProperty("user.home")) + File.separatorChar + "chessbot.settings");
    }
    
    private static void ensureInitialized() {
        if (Settings.properties == null) {
            Settings.properties = new Properties();
            try {
                if (getDefaultFile().exists()) {
                    Settings.properties.load(new BufferedInputStream(new FileInputStream(getDefaultFile())));
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void load(final File file) {
        try {
            Settings.properties.load(new BufferedInputStream(new FileInputStream(file)));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static String get(final String key) {
        ensureInitialized();
        return Settings.properties.getProperty(key);
    }
    
    public static String get(final String key, final String def) {
        ensureInitialized();
        final String v = Settings.properties.getProperty(key);
        if (v == null) {
            return def;
        }
        return v;
    }
    
    public static void set(final String key, final String value) {
        ensureInitialized();
        Settings.properties.setProperty(key, value);
    }
    
    public static void save() {
        save(getDefaultFile());
    }
    
    public static void save(final File file) {
        try {
            Settings.properties.save(new BufferedOutputStream(new FileOutputStream(file)), "");
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
