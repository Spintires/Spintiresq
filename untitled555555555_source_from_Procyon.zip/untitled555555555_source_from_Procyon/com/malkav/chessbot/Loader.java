// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.Random;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Enumeration;
import java.net.SocketException;
import java.net.NetworkInterface;
import java.security.Signature;
import java.awt.Component;
import javax.swing.JOptionPane;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.security.PublicKey;
import java.security.spec.KeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyFactory;
import java.awt.EventQueue;
import javax.swing.UIManager;

public class Loader
{
    public static void main(final String[] args) throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Chessbot().setVisible(true);
            }
        });
    }
    
    public static void mainOld(final String[] args) throws Exception {
        final byte[] pubKey;
        final byte[] arrby = pubKey = new byte[] { 48, -127, -97, 48, 13, 6, 9, 42, -122, 72, -122, -9, 13, 1, 1, 1, 5, 0, 3, -127, -115, 0, 48, -127, -119, 2, -127, -127, 0, -114, 80, -91, 76, -6, -43, -114, -102, 116, -113, -45, -95, -16, 7, -114, -95, 33, 126, 97, -106, -106, -126, -115, -43, -77, 97, 33, -91, 101, 59, 88, 118, -17, 114, -100, -3, 115, -103, 55, -21, -87, 28, 26, 64, -11, 50, 4, 23, -55, -61, 28, 2, -86, -102, 39, 69, 120, -104, 6, -40, 42, 49, 55, 107, -44, -116, -81, -23, 43, -31, -7, -124, 31, 4, -58, 68, -17, 95, 97, 9, -1, -26, 97, 13, -56, -20, 106, 109, -1, -126, -87, -120, -70, -77, -84, -94, 107, 101, -42, -110, -93, 54, 81, -59, 2, -82, -77, 45, -58, 68, -37, 44, 55, -23, 34, -55, -54, -99, 19, 63, -120, -52, -37, 41, 113, 94, -11, -37, 2, 3, 1, 0, 1 };
        final PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(pubKey));
        final byte[] hardwareId = fetchHardwareId();
        byte[] randomId = fetchRandomId();
        if (randomId.length != 6) {
            randomId = fetchRandomId(true);
        }
        final byte[] key = new byte[6];
        for (int i = 0; i < 6; ++i) {
            key[i] = (byte)((hardwareId[5 - i] ^ randomId[i] ^ 0x31) & 0xFF);
        }
        final byte[] sig = readSignature();
        check(key, sig, publicKey);
    }
    
    private static void check(final byte[] key, byte[] sig, final PublicKey publicKey) throws Exception {
        final String skey = buildString(key);
        String ssig;
        if (sig == null) {
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(skey), null);
            ssig = JOptionPane.showInputDialog(null, "Machine ID: " + skey + "\nThe above Machine ID is copied to the clipboard.\nPlease send it to dynamicfusion@hotmail.com, then paste the license key received below.\nThis machine will then be anchored down and secured.\nAll future release versions will launch without having to reinstall the key.", "Universal ChessBot Client V2.0 Activation", -1);
            if (ssig == null || ssig.length() == 0) {
                return;
            }
        }
        else {
            ssig = new String(sig);
        }
        boolean ok;
        if ((sig = unbuildString(ssig)) != null) {
            final Signature rsa = Signature.getInstance("SHA1withRSA");
            rsa.initVerify(publicKey);
            rsa.update(key);
            ok = rsa.verify(sig);
        }
        else {
            ok = false;
        }
        if (ok) {
            saveSignature(ssig);
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Chessbot().setVisible(true);
                }
            });
        }
        else {
            JOptionPane.showMessageDialog(null, "The license is not valid!", "Invalid license!", 0);
            check(key, null, publicKey);
        }
    }
    
    private static byte[] fetchHardwareId() {
        try {
            final Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            byte[] address = null;
            while (en.hasMoreElements()) {
                address = en.nextElement().getHardwareAddress();
                if (address != null && address.length > 0) {
                    break;
                }
            }
            return address;
        }
        catch (SocketException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private static byte[] fetchRandomId() {
        return fetchRandomId(false);
    }
    
    private static byte[] fetchRandomId(final boolean forceUpdate) {
        try {
            final File fl = new File(String.valueOf(System.getProperty("user.home")) + File.separatorChar + ".settings");
            if (!forceUpdate && fl.exists()) {
                final ByteArrayOutputStream out = new ByteArrayOutputStream();
                final BufferedInputStream in = new BufferedInputStream(new FileInputStream(fl));
                int l = 0;
                final byte[] b = new byte[32];
                while ((l = in.read(b)) != -1) {
                    out.write(b, 0, l);
                }
                in.close();
                return out.toByteArray();
            }
            final FileOutputStream out2 = new FileOutputStream(fl);
            final byte[] b2 = new byte[6];
            final Random r = new Random(System.currentTimeMillis());
            for (int i = 0; i < b2.length; ++i) {
                out2.write(b2[i] = (byte)(r.nextInt(256) & 0xFF));
            }
            out2.close();
            return b2;
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private static String buildString(final byte[] array) {
        final StringBuilder sb = new StringBuilder();
        for (final byte b : array) {
            final int x = b & 0xFF;
            final String h = Integer.toHexString(x);
            if (h.length() == 1) {
                sb.append("0");
            }
            sb.append(h);
        }
        return sb.toString();
    }
    
    private static byte[] unbuildString(final String s) {
        try {
            final byte[] b = new byte[s.length() / 2];
            for (int i = 0; i < s.length(); i += 2) {
                final int x = Integer.parseInt(s.substring(i, i + 2), 16);
                b[i / 2] = (byte)(x & 0xFF);
            }
            return b;
        }
        catch (Exception e) {
            return null;
        }
    }
    
    private static byte[] readSignature() {
        try {
            final File fl = new File(String.valueOf(System.getProperty("user.home")) + File.separatorChar + "chessbot.key");
            if (fl.exists()) {
                final ByteArrayOutputStream out = new ByteArrayOutputStream();
                final BufferedInputStream in = new BufferedInputStream(new FileInputStream(fl));
                int l = 0;
                final byte[] b = new byte[32];
                while ((l = in.read(b)) != -1) {
                    out.write(b, 0, l);
                }
                in.close();
                return out.toByteArray();
            }
            return null;
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private static void saveSignature(final String ssig) {
        try {
            final File fl = new File(String.valueOf(System.getProperty("user.home")) + File.separatorChar + "chessbot.key");
            final BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(fl));
            out.write(ssig.getBytes());
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
