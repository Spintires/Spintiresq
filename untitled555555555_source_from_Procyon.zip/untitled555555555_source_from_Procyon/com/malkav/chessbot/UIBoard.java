// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.awt.image.ImageObserver;
import java.util.Iterator;
import com.malkav.chessbot.engine.EngineBoard;
import java.util.HashMap;
import java.util.HashSet;
import java.io.IOException;
import java.awt.image.RenderedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.Point;
import java.util.Collections;
import java.awt.image.DataBufferByte;
import java.util.ArrayList;
import java.text.DecimalFormat;
import java.lang.reflect.Field;
import java.util.List;
import java.awt.image.BufferedImage;

public class UIBoard extends Board
{
    private int x;
    private int y;
    private int w;
    private int h;
    private int x2;
    private int y2;
    private int w2;
    private int h2;
    private long lastMove;
    private boolean forceMovement;
    private BufferedImage buffer88;
    private BufferedImage bufferIndicator;
    private int[] currentPlayerIndicator;
    private int[][] currentState;
    private int[] curSide;
    private int darkBlackWhiteThreshold;
    private int lightBlackWhiteThreshold;
    private List<Integer> myLastMoveIndexes;
    private Boolean whiteOnTop;
    private static Field fData;
    private boolean reset;
    private int kingX;
    private int rookLX;
    private int rookRX;
    private boolean canTopCastle;
    private boolean canBottomCastle;
    private int devThreshold;
    private DecimalFormat f3;
    private int dumpNum;
    private int gameNum;
    private double lastMouseX;
    private double lastMouseY;
    private double mouseSpeedX;
    private double mouseSpeedY;
    
    public UIBoard() {
        this.forceMovement = false;
        this.buffer88 = new BufferedImage(256, 256, 10);
        this.bufferIndicator = new BufferedImage(128, 128, 10);
        this.curSide = new int[64];
        this.darkBlackWhiteThreshold = 113;
        this.lightBlackWhiteThreshold = 143;
        this.myLastMoveIndexes = new ArrayList<Integer>();
        this.whiteOnTop = null;
        this.reset = false;
        this.canTopCastle = true;
        this.canBottomCastle = true;
        this.devThreshold = 20;
        this.f3 = new DecimalFormat("000");
        this.dumpNum = 1;
        this.gameNum = 1;
        this.lastMouseX = 0.0;
        this.lastMouseY = 0.0;
        this.mouseSpeedX = 1.0;
        this.mouseSpeedY = 1.0;
    }
    
    private static void init() {
        try {
            (UIBoard.fData = DataBufferByte.class.getDeclaredField("data")).setAccessible(true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void updateIndexes(final int[][] state) {
        if (this.whiteOnTop == null) {
            final ArrayList<Integer> devs = new ArrayList<Integer>();
            for (int y2 = 0; y2 < 8; ++y2) {
                for (int x = 0; x < 8; ++x) {
                    final int idx = y2 * 8 + x;
                    devs.add(state[idx][1]);
                }
            }
            Collections.sort(devs);
            this.devThreshold = (devs.get(31) + devs.get(32)) / 2;
            this.game.logDebug(String.valueOf(this.code) + ": Devs: " + devs);
            this.game.logDebug(String.valueOf(this.code) + ": Deviation threshold set to " + this.devThreshold);
            final ArrayList<Integer> lightColors = new ArrayList<Integer>();
            final ArrayList<Integer> darkColors = new ArrayList<Integer>();
            for (int y3 = 0; y3 < 8; ++y3) {
                for (int x2 = 0; x2 < 8; ++x2) {
                    final int idx2 = y3 * 8 + x2;
                    if (state[idx2][1] >= this.devThreshold) {
                        if (isDark(idx2)) {
                            darkColors.add(state[idx2][0]);
                        }
                        else {
                            lightColors.add(state[idx2][0]);
                        }
                    }
                }
            }
            Collections.sort(lightColors);
            Collections.sort(darkColors);
            this.game.logDebug(String.valueOf(this.code) + "/L: " + lightColors);
            this.game.logDebug(String.valueOf(this.code) + "/D: " + darkColors);
            this.lightBlackWhiteThreshold = (lightColors.get(7) + lightColors.get(8)) / 2;
            this.darkBlackWhiteThreshold = (darkColors.get(7) + darkColors.get(8)) / 2;
        }
        for (int y4 = 0; y4 < 8; ++y4) {
            for (int x3 = 0; x3 < 8; ++x3) {
                this.curSide[y4 * 8 + x3] = this.getColor(state, y4 * 8 + x3);
            }
        }
        if (this.whiteOnTop == null) {
            this.whiteOnTop = (this.curSide[0] == 2);
            this.currentState = new int[this.y * 8 + this.x][2];
            for (int y4 = 0; y4 < 8; ++y4) {
                for (int x3 = 0; x3 < 8; ++x3) {
                    final int idx3 = y4 * 8 + x3;
                    final int c = this.curSide[idx3];
                    if (y4 >= 2 && y4 < 6) {
                        if (c == 0) {
                            this.currentState[idx3][0] = state[idx3][0];
                            this.currentState[idx3][1] = state[idx3][1];
                        }
                        else {
                            this.currentState[idx3][0] = 128;
                            this.currentState[idx3][1] = 0;
                            this.curSide[idx3] = 0;
                        }
                    }
                    else if (c != 0) {
                        this.currentState[idx3][0] = state[idx3][0];
                        this.currentState[idx3][1] = state[idx3][1];
                    }
                    else {
                        this.currentState[idx3][0] = this.currentState[idx3 - idx3 % 8][1];
                        this.currentState[idx3][1] = 200;
                        this.curSide[idx3] = this.curSide[idx3 - idx3 % 8];
                    }
                }
            }
        }
    }
    
    public static boolean isDark(final int idx) {
        final Point p = indexToPoint(idx);
        if (p.y % 2 == 0) {
            return p.x % 2 == 1;
        }
        return p.x % 2 == 0;
    }
    
    public void setArea(final int x, final int y, final int w, final int h, final int x2, final int y2, final int w2, final int h2) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.x2 = x2;
        this.y2 = y2;
        this.w2 = w2;
        this.h2 = h2;
    }
    
    @Override
    public void dumpBoard() {
        this.dumpBoard(this.currentState);
    }
    
    private void dumpBoard(final int[][] state) {
        if (!this.game.getApp().isDebugEnabled()) {
            return;
        }
        this.game.logDebug("=== " + this.code + " " + this.darkBlackWhiteThreshold + "/" + this.lightBlackWhiteThreshold + " ===");
        for (int y = 0; y < 8; ++y) {
            final StringBuilder sb = new StringBuilder();
            for (int x = 0; x < 8; ++x) {
                sb.append(String.valueOf(this.curSide[y * 8 + x]) + ":" + this.getColor(state, y * 8 + x) + "|" + this.f3.format(state[y * 8 + x][0]) + "+" + this.f3.format(state[y * 8 + x][1]) + " ");
            }
            this.game.logDebug(sb.toString());
        }
        try {
            ImageIO.write(this.buffer88, "png", new File("out" + this.code + "-" + this.gameNum + "-" + this.dumpNum++ + ".png"));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void ensureInitialized() {
        if (this.currentState == null) {
            final BufferedImage boardImage = Screen.getCurrentScreen(this.x, this.y, this.w, this.h);
            final int[][] state = this.parse(boardImage);
            this.updateIndexes(state);
        }
    }
    
    @Override
    public void update() {
        this.update(true);
    }
    
    public void update(final boolean detectMove) {
        this.update(detectMove, 1);
    }
    
    public void update(final boolean detectMove, final int attempt) {
        if (!this.game.running) {
            return;
        }
        if (this.reset) {
            this.resetImpl();
            return;
        }
        final BufferedImage playerIndicatorImage = Screen.getCurrentScreen(this.x2, this.y2, this.w2, this.h2);
        final int[] lastPlayerIndicator = this.currentPlayerIndicator;
        this.currentPlayerIndicator = this.parseIndicator(playerIndicatorImage);
        if (detectMove && this.game.isAnimationTriggerEnabled(this)) {
            if (this.forceMovement) {
                this.forceMovement = false;
            }
            else {
                if (lastPlayerIndicator == null || this.isEquals(lastPlayerIndicator, this.currentPlayerIndicator)) {
                    return;
                }
                final int sleep = this.game.getAnimationTriggerTimer(this);
                if (sleep > 0) {
                    try {
                        Thread.sleep(sleep);
                    }
                    catch (InterruptedException ex) {}
                }
            }
        }
        BufferedImage boardImage = Screen.getCurrentScreen(this.x, this.y, this.w, this.h);
        final int[][] stateNew = this.parse(boardImage);
        List<Integer> diffs = null;
        if (detectMove) {
            diffs = this.compare(this.currentState, stateNew);
            if (diffs != null && diffs.size() == 0) {
                diffs = null;
            }
            if (diffs != null && !this.game.isAnimationTriggerEnabled(this)) {
                try {
                    Thread.sleep(this.game.isAnimationEnabled(this) ? ((long)this.game.getDelay()) : 10L);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                boardImage = Screen.getCurrentScreen(this.x, this.y, this.w, this.h);
                final int[][] stateNew2 = this.parse(boardImage);
                if (this.isDifferent(stateNew, stateNew2)) {
                    System.out.println("Waiting for animation to end...");
                    return;
                }
            }
        }
        if (this.isNoBoardDetected(diffs, stateNew)) {
            this.game.getApp().stopGame();
            return;
        }
        if (detectMove && diffs != null) {
            final ArrayList<String> sdiffs = new ArrayList<String>();
            for (final Integer d : diffs) {
                sdiffs.add(this.toNotation(d));
            }
            this.game.logDebug(String.valueOf(this.code) + ": Detected changes on " + sdiffs);
            final HashSet<Integer> used = new HashSet<Integer>();
            final HashMap<Integer, Integer> newSides = new HashMap<Integer, Integer>();
            final HashMap<Integer, Integer> oldSides = new HashMap<Integer, Integer>();
            int emptyToSide = 0;
            int sideToEmpty = 0;
            for (final int diff : diffs) {
                final int side0 = this.curSide[diff];
                final int side2 = this.getColor(stateNew, diff);
                newSides.put(diff, side2);
                oldSides.put(diff, side0);
                if (side0 == 0 && side2 != 0) {
                    ++emptyToSide;
                }
                else {
                    if (side0 == 0) {
                        continue;
                    }
                    if (side2 != 0) {
                        continue;
                    }
                    ++sideToEmpty;
                }
            }
            if (emptyToSide > sideToEmpty) {
                for (final int diff : diffs) {
                    final int side0 = this.curSide[diff];
                    final int side2 = this.getColor(stateNew, diff);
                    if (side0 != 0) {
                        if (side2 == 0) {
                            continue;
                        }
                        this.game.logDebug("fixing " + this.toNotation(diff) + " " + side2 + " => 0");
                        newSides.put(diff, 0);
                    }
                }
            }
            boolean castling = false;
            int castlingKingFrom = -1;
            int castlingKingTo = -1;
            int castlingRookFrom = -1;
            int castlingRookTo = -1;
            boolean castlingSide = false;
            if (this.canTopCastle) {
                this.game.logDebug("Checking for castling " + this.kingX + "/" + this.rookLX + "/" + this.rookRX);
                for (final int diff2 : diffs) {
                    if (this.myLastMoveIndexes.contains(diff2)) {
                        continue;
                    }
                    final int y = indexToPoint(diff2).y;
                    final int x = indexToPoint(diff2).x;
                    if (y != 0) {
                        continue;
                    }
                    final int oldSide = this.curSide[diff2];
                    final int newSide = this.getColor(stateNew, diff2);
                    if (newSide == 0) {
                        this.game.logDebug("empty " + this.toNotation(diff2) + " - " + x);
                        if (x == this.kingX) {
                            castlingKingFrom = diff2;
                            continue;
                        }
                        if (x == this.rookLX) {
                            castlingSide = false;
                            castlingRookFrom = diff2;
                            continue;
                        }
                        if (x == this.rookRX) {
                            castlingSide = true;
                            castlingRookFrom = diff2;
                            continue;
                        }
                    }
                    this.game.logDebug(" " + this.whiteOnTop + " " + newSide + " / y " + y);
                    if (this.whiteOnTop && ((newSide == 1 && y == 7) || (newSide == 2 && y == 0))) {
                        this.game.logDebug("wOnTop " + this.toNotation(diff2) + " - " + x);
                        if (x == 5 || x == 1) {
                            castlingKingTo = diff2;
                        }
                        else {
                            if (x != 4 && x != 2) {
                                continue;
                            }
                            castlingRookTo = diff2;
                        }
                    }
                    else {
                        if (this.whiteOnTop) {
                            continue;
                        }
                        if (newSide != 2 || y != 7) {
                            if (newSide != 1) {
                                continue;
                            }
                            if (y != 0) {
                                continue;
                            }
                        }
                        this.game.logDebug("wOnBottom " + this.toNotation(diff2) + " - " + x);
                        if (x == 2 || x == 6) {
                            castlingKingTo = diff2;
                        }
                        else {
                            if (x != 3 && x != 5) {
                                continue;
                            }
                            castlingRookTo = diff2;
                        }
                    }
                }
                this.game.logDebug("CST: K " + this.toNotation(castlingKingFrom) + "=>" + this.toNotation(castlingKingTo) + " / R " + this.toNotation(castlingRookFrom) + "=>" + this.toNotation(castlingRookTo) + " / S " + (castlingSide ? "R" : "L"));
                if (castlingKingTo != -1 || castlingRookTo != -1) {
                    if (castlingRookFrom == -1) {
                        final int x2 = indexToPoint(castlingKingTo).x;
                        if (this.rookLX == x2) {
                            this.game.logDebug(" rook origin is king destination at " + this.toNotation(castlingKingTo));
                            castlingRookFrom = castlingKingTo;
                            castlingSide = false;
                        }
                        else if (this.rookRX == x2) {
                            this.game.logDebug(" rook origin is king destination at " + this.toNotation(castlingKingTo));
                            castlingRookFrom = castlingKingTo;
                            castlingSide = true;
                        }
                        else {
                            this.game.logDebug(" can't find rook origin, X = " + x2 + " rooks @ " + this.rookLX + "/" + this.rookRX);
                        }
                    }
                    if (castlingKingFrom == -1) {
                        final int x2 = indexToPoint(castlingRookTo).x;
                        if (this.kingX == x2) {
                            castlingKingFrom = castlingRookTo;
                            this.game.logDebug(" king origin is rook destination at " + this.toNotation(castlingKingFrom));
                        }
                        else {
                            this.game.logDebug(" can't find king origin, X = " + x2 + " king @ " + this.kingX);
                        }
                    }
                    if (castlingKingFrom != -1 && Math.abs(castlingKingFrom - castlingKingTo) >= 2) {
                        final int kx0 = indexToPoint(castlingKingFrom).x;
                        final int kx2 = indexToPoint(castlingKingTo).x;
                        this.game.logDebug("rook didnt move... king " + kx0 + "=>" + kx2 + " / rooks At " + this.rookLX + "/" + this.rookRX);
                        if (kx2 < this.rookLX && kx0 > this.rookLX && (this.rookLX == 2 || this.rookLX == 3)) {
                            this.game.logDebug(" left king hop!");
                            castlingSide = false;
                            castlingRookFrom = this.rookLX;
                            castlingRookTo = this.rookLX;
                        }
                        else if (kx2 > this.rookRX && kx0 < this.rookRX && (this.rookRX == 5 || this.rookRX == 6)) {
                            this.game.logDebug(" right king hop!");
                            castlingSide = true;
                            castlingRookFrom = this.rookRX;
                            castlingRookTo = this.rookRX;
                        }
                    }
                    if (castlingKingTo == -1) {
                        final int rx0 = indexToPoint(castlingRookFrom).x;
                        final int rx2 = indexToPoint(castlingRookTo).x;
                        if (this.curSide[this.kingX] != 0) {
                            this.game.logDebug("king didnt move... rook " + rx0 + "=>" + rx2 + " / king At " + this.kingX);
                            if ((this.kingX == 1 || this.kingX == 2) && rx0 < this.kingX && rx2 > this.kingX) {
                                castlingSide = false;
                                castlingKingFrom = this.kingX;
                                castlingKingTo = this.kingX;
                            }
                            else if ((this.kingX == 6 || this.kingX == 7) && rx0 > this.kingX && rx2 < this.kingX) {
                                castlingSide = false;
                                castlingKingFrom = this.kingX;
                                castlingKingTo = this.kingX;
                            }
                        }
                    }
                    if (castlingKingFrom != -1 && castlingKingTo != -1) {
                        this.canTopCastle = false;
                    }
                    if (castlingKingFrom != -1 && castlingRookFrom != -1 && castlingKingTo != -1 && castlingRookTo != -1) {
                        castling = true;
                        this.game.log("CASTLING!!!");
                        this.game.logDebug(" K " + this.toNotation(castlingKingFrom) + "=>" + this.toNotation(castlingKingTo) + " / R " + this.toNotation(castlingRookFrom) + "=>" + this.toNotation(castlingRookTo) + " / S " + (castlingSide ? "R" : "L"));
                    }
                }
            }
            boolean enPassant = diffs.size() - this.myLastMoveIndexes.size() == 3;
            this.game.logDebug("en passant? " + diffs + " - " + this.myLastMoveIndexes);
            if (enPassant) {
                final ArrayList<Integer> newDiffs = new ArrayList<Integer>();
                this.game.logDebug("Checking en passant");
                for (final int diff3 : diffs) {
                    if (this.myLastMoveIndexes.contains(diff3)) {
                        continue;
                    }
                    newDiffs.add(diff3);
                }
                final Point p0 = indexToPoint(newDiffs.get(0));
                final Point p2 = indexToPoint(newDiffs.get(1));
                final Point p3 = indexToPoint(newDiffs.get(2));
                final Point pl0 = indexToPoint(this.myLastMoveIndexes.get(0));
                final Point pl2 = indexToPoint(this.myLastMoveIndexes.get(1));
                if (this.curSide[newDiffs.get(0)] == 0 && p0.x == pl2.x) {
                    this.myLastMoveIndexes.add(newDiffs.get(0));
                }
                else if (this.curSide[newDiffs.get(1)] == 0 && p2.x == pl2.x) {
                    this.myLastMoveIndexes.add(newDiffs.get(1));
                }
                else if (this.curSide[newDiffs.get(2)] == 0 && p3.x == pl2.x) {
                    this.myLastMoveIndexes.add(newDiffs.get(2));
                }
                else {
                    this.game.logDebug("Could not solve the en passant!!");
                }
            }
            else {
                final boolean bl;
                enPassant = (bl = ((diffs.size() == 1 || diffs.size() == 3) && this.myLastMoveIndexes.size() == 2));
                if (enPassant) {
                    int newDiff = -1;
                    for (final int d2 : diffs) {
                        if (this.myLastMoveIndexes.contains(d2)) {
                            continue;
                        }
                        newDiff = d2;
                        break;
                    }
                    if (newDiff != -1 && newSides.get(newDiff) == 0) {
                        final Point p2 = indexToPoint(newDiff);
                        final Point p0A = indexToPoint(this.myLastMoveIndexes.get(0));
                        final Point p0B = indexToPoint(this.myLastMoveIndexes.get(1));
                        if (p2.x == p0B.x && Math.abs(p2.y - p0B.y) == 1 && Math.abs(p2.x - p0A.x) == 1 && p0A.y == p2.y) {
                            used.add(newDiff);
                            this.game.logDebug("Fixed en passant from last move");
                        }
                    }
                }
            }
            for (final int diff4 : diffs) {
                if (used.contains(diff4)) {
                    continue;
                }
                int diffTarget = -1;
                final int side3 = this.curSide[diff4];
                final int side4 = newSides.get(diff4);
                if (side3 == 0) {
                    continue;
                }
                if (side4 != 0 && !castling) {
                    continue;
                }
                System.out.println(String.valueOf(this.code) + ": " + this.toNotation(diff4) + " is empty now");
                this.game.logDebug(String.valueOf(this.code) + ": " + this.toNotation(diff4) + " is empty now");
                if (!castling) {
                    for (final int diff5 : diffs) {
                        if (diff5 != diff4 && !used.contains(diff5)) {
                            final int side5;
                            if ((side5 = newSides.get(diff5)) != side3) {
                                continue;
                            }
                            diffTarget = diff5;
                            break;
                        }
                    }
                }
                final int diff6;
                final int side6;
                if (!castling && diffTarget == -1 && this.myLastMoveIndexes.size() >= 2 && (side6 = this.getColor(stateNew, diff6 = this.myLastMoveIndexes.get(1))) == side3) {
                    diffTarget = diff6;
                    this.game.logDebug(String.valueOf(this.code) + ": Found a target for " + this.toNotation(diff4) + " on a double capture " + this.toNotation(diff6));
                }
                if (castling || diffTarget != -1) {
                    System.out.println(String.valueOf(this.code) + ": target at " + this.toNotation(diffTarget));
                    this.game.logDebug(String.valueOf(this.code) + ": target at " + this.toNotation(diffTarget));
                    if ((!this.whiteOnTop && side3 == 1) || (this.whiteOnTop && side3 == 2)) {
                        if (!castling) {
                            this.curSide[diffTarget] = this.curSide[diff4];
                            this.curSide[diff4] = 0;
                            used.add(diff4);
                            used.add(diffTarget);
                        }
                        else {
                            this.curSide[castlingKingFrom] = 0;
                            this.curSide[castlingRookFrom] = 0;
                            this.curSide[castlingKingTo] = side3;
                            this.curSide[castlingRookTo] = side3;
                            if (!used.contains(castlingKingFrom)) {
                                used.add(castlingKingFrom);
                            }
                            if (!used.contains(castlingKingTo)) {
                                used.add(castlingKingTo);
                            }
                            if (!used.contains(castlingRookFrom)) {
                                used.add(castlingRookFrom);
                            }
                            if (!used.contains(castlingRookTo)) {
                                used.add(castlingRookTo);
                            }
                        }
                        this.game.log(String.valueOf(this.code) + ": " + ((side3 == 1) ? "B" : "W") + ": " + this.toNotation(diff4) + "=>" + this.toNotation(diffTarget));
                        this.dumpBoard(stateNew);
                        if (castling) {
                            this.game.logDebug(String.valueOf(this.code) + ": CASTLING!! " + this.toNotation(castlingKingFrom) + "=>" + this.toNotation(castlingRookFrom) + " " + diffTarget + "|" + diffTarget % 8);
                            if (this.mirror instanceof EngineBoard && ((EngineBoard)this.mirror).getEngine().is960Enabled()) {
                                this.mirror.move(63 - castlingKingFrom, 63 - castlingRookFrom);
                            }
                            else {
                                this.mirror.move(63 - castlingKingFrom, 63 - castlingKingTo, 63 - castlingRookFrom, 63 - castlingRookTo);
                            }
                        }
                        else {
                            this.mirror.move(63 - diff4, 63 - diffTarget);
                        }
                    }
                    else {
                        final Point p4 = indexToPoint(diff4);
                        final Point p5 = indexToPoint(diffTarget);
                        if (p4.y == p5.y && p4.y == 7) {
                            if (p4.x != 0 || (p5.x != 2 && p5.x != 3)) {
                                if (p4.x != 7) {
                                    continue;
                                }
                                if (p5.x != 5 && p5.x != 4) {
                                    continue;
                                }
                            }
                            this.game.logDebug("Detected castling from last engine move");
                            used.add(diff4);
                            used.add(diffTarget);
                        }
                        else if (used.size() >= 2) {
                            this.game.logDebug("Didn't process all the changes, but found a move, ignoring the extra ones");
                        }
                        else {
                            if (attempt >= 300) {
                                continue;
                            }
                            try {
                                Thread.sleep(this.game.isAnimationEnabled(this) ? 250L : 60L);
                            }
                            catch (InterruptedException e2) {
                                e2.printStackTrace();
                            }
                            this.game.logDebug(String.valueOf(this.code) + ": Trying again... Attempt #" + (attempt + 1));
                            this.update(detectMove, attempt + 1);
                            return;
                        }
                    }
                }
                else {
                    this.game.logDebug(String.valueOf(this.code) + ": Didn't find a target for " + this.toNotation(diff4));
                    if (attempt >= 3) {
                        continue;
                    }
                    try {
                        Thread.sleep(this.game.isAnimationEnabled(this) ? 250L : 60L);
                    }
                    catch (InterruptedException e3) {
                        e3.printStackTrace();
                    }
                    this.game.logDebug(String.valueOf(this.code) + ": Trying again... Attempt #" + (attempt + 1));
                    this.update(detectMove, attempt + 1);
                    return;
                }
            }
            this.game.logDebug(String.valueOf(this.code) + ": Processed " + used.size() + "/" + diffs.size());
            for (final int diff4 : diffs) {
                final int side7 = oldSides.get(diff4);
                final int side1Raw = this.getColor(stateNew, diff4);
                final int side8 = this.curSide[diff4];
                this.game.logDebug(String.valueOf(this.code) + ": " + this.toNotation(diff4) + ": " + side7 + " => " + side1Raw + "/" + side8 + (used.contains(diff4) ? "!!" : "??"));
            }
            if (diffs.size() >= 2 && used.size() == 0) {
                if (attempt < 3) {
                    try {
                        Thread.sleep(this.game.isAnimationEnabled(this) ? 250L : 60L);
                    }
                    catch (InterruptedException e4) {
                        e4.printStackTrace();
                    }
                    this.game.logDebug("Trying again... Attempt #" + (attempt + 1));
                    System.out.println("Trying again... Attempt #" + (attempt + 1));
                    this.update(detectMove, attempt + 1);
                    return;
                }
                this.dumpBoard(stateNew);
                try {
                    ImageIO.write(this.buffer88, "png", new File("out.png"));
                }
                catch (IOException e5) {
                    e5.printStackTrace();
                }
            }
        }
        this.currentState = stateNew;
        if (diffs != null || !detectMove) {
            this.updateIndexes(stateNew);
        }
    }
    
    private void initCastling() {
        String row = this.game.getStartPos();
        if (row == null) {
            row = (this.isWhiteOnTop() ? "RNBKQBNR" : "RNBQKBNR");
        }
        row = row.toUpperCase();
        this.kingX = row.indexOf(75);
        this.rookLX = row.indexOf(82);
        this.rookRX = row.lastIndexOf(82);
        this.canTopCastle = true;
        this.canBottomCastle = true;
    }
    
    private boolean isNoBoardDetected(final List<Integer> diffs, final int[][] state) {
        if (diffs != null && diffs.size() > 10) {
            this.game.logDebug("No board detected... Number of diffs: " + diffs.size());
            return true;
        }
        int empty = 0;
        for (int i = 0; i < 64; ++i) {
            final int c = this.getColor(state, i);
            if (c == 0) {
                ++empty;
            }
        }
        if (empty < 16) {
            this.game.logDebug("No board detected... Too few empty squares: " + empty);
            return true;
        }
        return false;
    }
    
    @Override
    public void move(final String m1, final String m2) {
        System.out.println("UI.move " + m1 + "=>" + m2);
        final Point p1 = this.fromNotation(m1);
        final Point p2 = this.fromNotation(m2);
        final int idx1 = this.chessPointToIndex(p1);
        final int idx2 = this.chessPointToIndex(p2);
        this.move(idx1, idx2);
    }
    
    private Point fromNotation(final String notation) {
        final int col = notation.toLowerCase().charAt(0) - 'a';
        final int row = notation.charAt(1) - '1';
        return new Point(col, row);
    }
    
    @Override
    public void moveImpl(final int from, final int to, final int from2, final int to2) {
        final long d = System.currentTimeMillis() - this.lastMove;
        if (d < (this.game.isAnimationEnabled(this) ? 300 : 10)) {
            try {
                Thread.sleep((this.game.isAnimationEnabled(this) ? 300 : 10) - d);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.lastMove = System.currentTimeMillis();
        this.game.log(String.valueOf(this.code) + ": Moving: " + this.toNotation(from) + " => " + this.toNotation(to));
        this.myLastMoveIndexes.clear();
        this.myLastMoveIndexes.add(from);
        this.myLastMoveIndexes.add(to);
        if (from2 != -1) {
            this.myLastMoveIndexes.add(from2);
        }
        if (to2 != -1) {
            this.myLastMoveIndexes.add(to2);
        }
        this.move(indexToPoint(from), indexToPoint(to));
        this.curSide[to] = this.curSide[from];
        this.curSide[from] = 0;
        this.game.appFocus();
    }
    
    public void move(final Point from, final Point to) {
        final double cellW = this.w / 8.0;
        final double cellH = this.h / 8.0;
        final int fromX = this.x + (int)(from.x * cellW + (0.5 + 0.25 * Math.random()) * cellW);
        final int fromY = this.y + (int)(from.y * cellH + (0.5 + 0.25 * Math.random()) * cellH);
        final int toX = this.x + (int)(to.x * cellW + (0.5 + 0.25 * Math.random()) * cellW);
        final int toY = this.y + (int)(to.y * cellH + (0.5 + 0.25 * Math.random()) * cellH);
        if (this.game.getApp().isClick()) {
            Mouse.click(fromX, fromY);
        }
        else {
            Mouse.grab(fromX, fromY);
        }
        int delay = this.game.getApp().getMouseDelay();
        if (delay > 0) {
            System.out.println("Delay: " + delay);
            try {
                Thread.sleep(delay);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (this.game.getApp().isClick()) {
            Mouse.click(toX, toY);
        }
        else {
            Mouse.release(toX, toY);
        }
        delay = this.game.getApp().getMouseDelay();
        if (delay > 1) {
            try {
                Thread.sleep(delay / 2);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.lastMouseX = toX - this.x;
        this.lastMouseY = toY - this.y;
    }
    
    private int getColor(final int[][] state, final int idx) {
        final int c = state[idx][0];
        final int d = state[idx][1];
        if (d < this.devThreshold) {
            return 0;
        }
        if (isDark(idx)) {
            if (c <= this.darkBlackWhiteThreshold) {
                return 1;
            }
            return 2;
        }
        else {
            if (c <= this.lightBlackWhiteThreshold) {
                return 1;
            }
            return 2;
        }
    }
    
    public static Point indexToMirrorPoint(final int idx) {
        final Point p = indexToPoint(idx);
        p.x = 7 - p.x;
        p.y = 7 - p.y;
        return p;
    }
    
    public int chessPointToIndex(final Point p) {
        int idx = (7 - p.y) * 8 + p.x;
        if (this.whiteOnTop) {
            idx = 63 - idx;
        }
        return idx;
    }
    
    public static Point indexToPoint(final int idx) {
        final int x = idx % 8;
        final int y = idx / 8;
        return new Point(x, y);
    }
    
    public boolean isEquals(final int[] state0, final int[] state1) {
        return state0[0] == state1[0] && state0[1] == state1[1];
    }
    
    public boolean isDifferent(final int[][] state0, final int[][] state1) {
        final List<Integer> l = this.compare(state0, state1);
        return l != null && l.size() > 1;
    }
    
    public List<Integer> compare(final int[][] state0, final int[][] state1) {
        if (state0 == null || state1 == null) {
            return null;
        }
        final ArrayList<Integer> changes = new ArrayList<Integer>();
        for (int y = 0; y < 8; ++y) {
            for (int x = 0; x < 8; ++x) {
                final int idx = y * 8 + x;
                final int delta0 = Math.abs(state0[idx][0] - state1[idx][0]);
                final int delta2 = Math.abs(state0[idx][1] - state1[idx][1]);
                if (delta0 >= 4 || delta2 >= 4) {
                    final int c = this.getColor(state1, idx);
                    if (this.myLastMoveIndexes.contains(idx) && (c == 0 || c == (this.whiteOnTop ? 1 : 2))) {
                        this.game.logDebug(String.valueOf(this.code) + ": Ignoring " + this.toNotation(idx) + ": " + c);
                    }
                    else {
                        changes.add(idx);
                        this.game.logDebug(String.valueOf(this.code) + ": Change on " + this.toNotation(idx) + ": " + this.getColor(state0, idx) + "=>" + c + " / " + state0[idx][0] + "/" + state1[idx][0] + " || " + state0[idx][1] + "/" + state1[idx][1]);
                    }
                }
            }
        }
        return changes;
    }
    
    private String toNotation(final int idx) {
        if (idx == -1) {
            return "?";
        }
        return this.toStringPos(indexToPoint(idx));
    }
    
    private String toStringPos(final Point p) {
        return this.toStringPos(p.x, p.y);
    }
    
    private String toStringPos(int x, int y) {
        if (this.whiteOnTop) {
            x = 7 - x;
            y = 7 - y;
        }
        return String.valueOf(String.valueOf((char)(97 + x))) + (8 - y);
    }
    
    private int[][] parse(final BufferedImage image) {
        try {
            int padding = this.game.getApp().getPadding();
            padding = Math.min(12, Math.max(4, padding));
            final int cellSize = 32;
            this.buffer88.getGraphics().drawImage(image.getScaledInstance(8 * cellSize, 8 * cellSize, 16), 0, 0, null);
            final byte[] data = (byte[])UIBoard.fData.get(this.buffer88.getRaster().getDataBuffer());
            final int[][] state = new int[64][2];
            for (int y = 0; y < 8; ++y) {
                for (int x = 0; x < 8; ++x) {
                    int total = 0;
                    for (int y2 = padding + 4; y2 < cellSize - padding + 4; ++y2) {
                        for (int x2 = padding; x2 < cellSize - padding; ++x2) {
                            final int idx2 = (y * cellSize + y2) * (8 * cellSize) + (x * cellSize + x2);
                            total += (data[idx2] & 0xFF);
                        }
                    }
                    final int avg = (int)(total / Math.pow(cellSize - 2 * padding, 2.0));
                    int dev = 0;
                    for (int y3 = padding + 4; y3 < cellSize - padding + 4; ++y3) {
                        for (int x3 = padding; x3 < cellSize - padding; ++x3) {
                            final int idx3 = (y * cellSize + y3) * (8 * cellSize) + (x * cellSize + x3);
                            final int c = data[idx3] & 0xFF;
                            dev += (c - avg) * (c - avg);
                        }
                    }
                    dev = (state[y * 8 + x][1] = (int)Math.sqrt(dev / Math.pow(cellSize - 2 * padding, 2.0)));
                    total = 0;
                    for (int y3 = padding + 6; y3 < cellSize - padding + 4; ++y3) {
                        for (int x3 = padding + 2; x3 < cellSize - padding - 2; ++x3) {
                            final int idx3 = (y * cellSize + y3) * (8 * cellSize) + (x * cellSize + x3);
                            total += (data[idx3] & 0xFF);
                        }
                    }
                    final int color = state[y * 8 + x][0] = total / ((cellSize - padding - padding - 4) * (cellSize - padding - padding - 2));
                }
            }
            return state;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private int[] parseIndicator(final BufferedImage image) {
        try {
            this.bufferIndicator.getGraphics().drawImage(image.getScaledInstance(128, 128, 16), 0, 0, null);
            final byte[] data = (byte[])UIBoard.fData.get(this.bufferIndicator.getRaster().getDataBuffer());
            final int[] state = new int[2];
            int total = 0;
            for (int idx = 0; idx < data.length; ++idx) {
                total += (data[idx] & 0xFF);
            }
            final int avg = state[0] = total / data.length;
            long dev = 0L;
            for (int idx2 = 0; idx2 < data.length; ++idx2) {
                final int c = data[idx2] & 0xFF;
                dev += (c - avg) * (c - avg);
            }
            dev = (long)Math.sqrt((double)(dev / 256L));
            state[1] = (int)dev;
            return state;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public void reset() {
        this.reset = true;
    }
    
    private void resetImpl() {
        ++this.gameNum;
        this.dumpNum = 1;
        this.myLastMoveIndexes.clear();
        this.curSide = new int[64];
        this.currentState = null;
        this.reset = false;
        this.whiteOnTop = null;
        this.ensureInitialized();
        this.initCastling();
    }
    
    @Override
    public void livingMouse() {
        final double x1 = this.lastMouseX + this.mouseSpeedX;
        final double y1 = this.lastMouseY + this.mouseSpeedY;
        Mouse.move((int)(this.x + x1), (int)(this.y + y1));
        this.lastMouseX = x1;
        this.lastMouseY = y1;
        this.mouseSpeedX = ((x1 >= this.w) ? -2.0 : ((x1 <= 0.0) ? 2.0 : (this.mouseSpeedX += Math.random() * 0.6 - 0.3)));
        this.mouseSpeedY = ((y1 >= this.h) ? -2.0 : ((y1 <= 0.0) ? 2.0 : (this.mouseSpeedY += Math.random() * 0.6 - 0.3)));
    }
    
    public Boolean isWhiteOnTop() {
        return this.whiteOnTop;
    }
    
    public void setForceMovement(final boolean forceMovement) {
        this.forceMovement = forceMovement;
    }
    
    public void initGame() {
        this.ensureInitialized();
        this.initCastling();
    }
    
    static {
        init();
    }
}
