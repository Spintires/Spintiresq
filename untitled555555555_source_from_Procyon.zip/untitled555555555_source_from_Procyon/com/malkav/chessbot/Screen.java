// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.awt.Toolkit;
import java.awt.MouseInfo;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.Point;
import java.awt.Robot;

public class Screen
{
    private static Robot R;
    private static Point lastMouse;
    
    public static void check() {
        if (Screen.R == null) {
            try {
                Screen.R = new Robot();
            }
            catch (Exception ex) {}
        }
    }
    
    public static BufferedImage getCurrentScreen(final int x, final int y, final int w, final int h) {
        return Screen.R.createScreenCapture(new Rectangle(x, y, w, h));
    }
    
    public static int getRGB(final int x, final int y) {
        return Screen.R.getPixelColor(x, y).getRGB();
    }
    
    public static boolean isOnStartSpot() {
        final Point p = MouseInfo.getPointerInfo().getLocation();
        return p.x < 10 && p.y < 10;
    }
    
    public static boolean isOnStopSpot() {
        final Point p = MouseInfo.getPointerInfo().getLocation();
        return p.x > Toolkit.getDefaultToolkit().getScreenSize().width - 10 && p.y < 10;
    }
    
    public static void checkpoint() {
        Screen.lastMouse = MouseInfo.getPointerInfo().getLocation();
    }
    
    public static boolean needsPause() {
        final Point p = MouseInfo.getPointerInfo().getLocation();
        return Math.abs(p.x - Screen.lastMouse.x) + Math.abs(p.y - Screen.lastMouse.y) > 5;
    }
    
    static {
        Screen.R = null;
        Screen.lastMouse = null;
    }
}
