// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import javax.swing.SpinnerModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import com.malkav.chessbot.engine.OptionType;
import java.util.List;
import com.oracle.spring.SpringUtilities;
import javax.swing.SpringLayout;
import java.util.Iterator;
import javax.swing.JComponent;
import com.malkav.chessbot.engine.EngineOption;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.Toolkit;
import com.malkav.chessbot.engine.Engine;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import javax.swing.JFileChooser;
import java.awt.Container;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.LayoutManager;
import javax.swing.BoxLayout;
import javax.swing.KeyStroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.malkav.chessbot.engine.EngineBoard;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JDialog;

public class EngineConfigDialog extends JDialog
{
    private JLabel lblEnginePath;
    private JPanel pnlEngine;
    private JScrollPane pnlOptionsContainer;
    private JPanel pnlOptions;
    private JPanel pnlButtons;
    private EngineBoard board;
    
    public EngineConfigDialog(final EngineBoard board) {
        this.lblEnginePath = new JLabel();
        this.pnlEngine = new JPanel();
        this.pnlOptionsContainer = new JScrollPane();
        this.setDefaultCloseOperation(2);
        this.setModal(true);
        this.setAlwaysOnTop(true);
        this.board = board;
        this.setEngine(board.getEngine());
        this.initComponents();
    }
    
    private void initComponents() {
        this.setTitle("Engine Options");
        final ActionListener actionClose = new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                EngineConfigDialog.this.dispose();
            }
        };
        this.getRootPane().registerKeyboardAction(actionClose, KeyStroke.getKeyStroke(27, 0), 2);
        this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), 1));
        this.getContentPane().add(this.lblEnginePath);
        this.getContentPane().add(this.pnlEngine);
        this.getContentPane().add(this.pnlOptionsContainer);
        this.pnlButtons = new JPanel();
        this.getContentPane().add(this.pnlButtons);
        final JButton btnOK = new JButton("OK");
        btnOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                EngineConfigDialog.this.save();
                EngineConfigDialog.this.dispose();
            }
        });
        final JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(actionClose);
        this.pnlButtons.add(btnOK);
        this.pnlButtons.add(btnCancel);
        this.pnlEngine.setLayout(new BoxLayout(this.pnlEngine, 1));
        final JButton btnChoose = new JButton("Choose Engine...");
        this.pnlEngine.add(btnChoose);
        btnChoose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final JFileChooser chooser = new JFileChooser();
                final String lastPath = Settings.get("engine.defaultFolder");
                if (lastPath != null) {
                    chooser.setCurrentDirectory(new File(lastPath));
                }
                final FileNameExtensionFilter filter = new FileNameExtensionFilter("Executable Files", new String[] { "exe" });
                chooser.setFileFilter(filter);
                final int returnVal = chooser.showOpenDialog(EngineConfigDialog.this);
                if (returnVal == 0) {
                    EngineConfigDialog.this.setEnginePath(chooser.getSelectedFile().getAbsolutePath());
                }
            }
        });
    }
    
    public void setEngine(final Engine engine) {
        if (engine == null) {
            return;
        }
        this.lblEnginePath.setText(engine.getPath());
        Settings.set("engine.defaultFolder", engine.getEngineParentPath());
        Settings.set("engine.enginePath", engine.getPath());
        Settings.save();
        this.setupOptionsUI();
        this.pack();
    }
    
    @Override
    public void pack() {
        super.pack();
        this.setLocationRelativeTo(null);
        final int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        final int maxHeight = (int)(screenHeight * 0.7);
        if (this.getSize().height > maxHeight) {
            this.setSize(new Dimension(this.getSize().width, maxHeight));
        }
        int y;
        if ((y = this.getLocation().y) + maxHeight >= screenHeight - 200) {
            y = screenHeight - 200 - maxHeight;
            this.setLocation(new Point(this.getLocation().x, y));
        }
    }
    
    @Override
    public void dispose() {
        for (final EngineOption option : this.board.getEngine().getOptions()) {
            option.setComponent(null);
        }
        super.dispose();
    }
    
    public void save() {
        for (final EngineOption option : this.board.getEngine().getOptions()) {
            option.updateEngine(this.board.getEngine());
        }
        Settings.save();
    }
    
    public void setEnginePath(final String path) {
        final Engine engine = new Engine(path);
        engine.init();
        engine.loadLastOptions();
        this.board.setEngine(engine);
        this.setEngine(engine);
    }
    
    private void setupOptionsUI() {
        if (this.pnlOptions != null) {
            this.pnlOptionsContainer.getViewport().remove(this.pnlOptions);
        }
        this.pnlOptions = new JPanel(new SpringLayout());
        this.pnlOptionsContainer.getViewport().add(this.pnlOptions);
        final List<EngineOption> options = this.board.getEngine().getOptions();
        int validOptions = 0;
        for (final EngineOption option : options) {
            if (!this.addOption(option)) {
                continue;
            }
            ++validOptions;
        }
        SpringUtilities.makeCompactGrid(this.pnlOptions, validOptions, 2, 6, 6, 6, 6);
    }
    
    private boolean addOption(final EngineOption option) {
        String lbl = null;
        JComponent value = null;
        final OptionType type = option.getType();
        if (type == OptionType.check) {
            final JCheckBox chk = (JCheckBox)(value = new JCheckBox(option.getName()));
        }
        else if (type == OptionType.string) {
            lbl = option.getName();
            final JTextField txt = (JTextField)(value = new JTextField());
        }
        else if (type == OptionType.button) {
            value = new JButton(option.getName());
            ((JButton)value).addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(final ActionEvent e) {
                    EngineConfigDialog.this.board.getEngine().send("setoption name " + option.getName());
                }
            });
        }
        else if (type == OptionType.spin) {
            lbl = option.getName();
            final SpinnerNumberModel model = new SpinnerNumberModel(Math.max(option.getMin(), Math.min(option.getMax(), option.getValueAsInt())), option.getMin(), option.getMax(), 1);
            value = new JSpinner(model);
        }
        if (value != null) {
            option.setComponent(value);
            this.pnlOptions.add(new JLabel(lbl));
            this.pnlOptions.add(value);
            return true;
        }
        return false;
    }
}
