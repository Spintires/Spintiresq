// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;

public class Mouse
{
    private static Robot R;
    
    public static void check() {
        if (Mouse.R == null) {
            try {
                Mouse.R = new Robot();
            }
            catch (Exception ex) {}
        }
    }
    
    static Point getCurrentPoint() {
        return MouseInfo.getPointerInfo().getLocation();
    }
    
    static void click(final int x, final int y) {
        Mouse.R.mouseMove(x, y);
        try {
            Thread.sleep(10L);
        }
        catch (Exception ex) {}
        Mouse.R.mousePress(16);
        try {
            Thread.sleep(10L);
        }
        catch (Exception ex2) {}
        Mouse.R.mouseRelease(16);
    }
    
    static void move(final int x, final int y) {
        Mouse.R.mouseMove(x, y);
    }
    
    static void grab(final int x, final int y) {
        Mouse.R.mouseMove(x, y);
        Mouse.R.mousePress(16);
        try {
            Thread.sleep(30L);
        }
        catch (Exception ex) {}
    }
    
    static void release(final int x, final int y) {
        Mouse.R.mouseMove(x, y);
        try {
            Thread.sleep(30L);
        }
        catch (Exception ex) {}
        Mouse.R.mouseRelease(16);
    }
    
    static void clear() {
        Mouse.R.mouseMove(0, 0);
    }
    
    static {
        Mouse.R = null;
    }
}
