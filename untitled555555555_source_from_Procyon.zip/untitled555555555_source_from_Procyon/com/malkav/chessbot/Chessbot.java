// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import java.text.SimpleDateFormat;
import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.io.FileNotFoundException;
import java.util.Date;
import java.io.PrintWriter;
import java.io.File;
import javax.swing.filechooser.FileFilter;
import javax.swing.JFileChooser;
import java.util.Iterator;
import javax.swing.GroupLayout;
import java.awt.GridLayout;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.FlowLayout;
import java.util.Arrays;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.BoxLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Insets;
import java.awt.Dimension;
import java.net.URL;
import java.awt.Toolkit;
import javax.swing.text.DefaultCaret;
import java.awt.KeyboardFocusManager;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.text.DecimalFormat;
import java.util.regex.Pattern;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import com.malkav.chessbot.engine.EngineBoard;
import java.text.DateFormat;
import java.awt.KeyEventDispatcher;
import javax.swing.JFrame;

public class Chessbot extends JFrame implements KeyEventDispatcher
{
    private static final DateFormat fDateFormat;
    private boolean isPointSet;
    private EngineConfigDialog dlgEngineConfig;
    private Game gameEngine;
    private Board Board1;
    private EngineBoard engineBoard;
    private UIBoard uiBoard;
    private JTextField txtMaxTime;
    private JTextField txtDepth;
    private JTextField txt960Row;
    private JCheckBox chk960Row;
    private JPanel pBestMoves;
    private JLabel lblPonder;
    private JLabel lblBest1Move;
    private JLabel lblBest1Extra;
    private JLabel lblBest2Move;
    private JLabel lblBest2Extra;
    private JLabel lblBest3Move;
    private JLabel lblBest3Extra;
    private JLabel lblBest4Move;
    private JLabel lblBest4Extra;
    private JPanel p1;
    private JPanel p2;
    private JPanel p3;
    private JTextField txtTrigger;
    private JTextField txtPadding;
    private JCheckBox chkClick;
    private JCheckBox chkBook;
    private JCheckBox chkManualMode;
    private StringBuilder sbDebugLog;
    private static Pattern PAT_TIMER;
    private static DecimalFormat f2;
    private JPanel BGPanel;
    private JTextField BX1Text;
    private JTextField BX2Text;
    private JTextField BY1Text;
    private JTextField BY2Text;
    private JTextField BX12Text;
    private JTextField BY12Text;
    private JTextField txtDelay;
    private JLabel DelayLabel;
    private JTextField txtMouseDelayMin;
    private JTextField txtMouseDelayMax;
    private JLabel MouseDelayLabel;
    private JButton LoadButton;
    private JTextArea Log;
    private JScrollPane LogScrollPane;
    private JCheckBox chkAnimation1;
    private JCheckBox chkAnimationTrigger1;
    private JCheckBox chkDeadMouse;
    private JCheckBox chkDebug;
    private JButton SaveButton;
    private JButton SetButton;
    private JButton StartButton;
    private JButton ResetButton;
    private JLabel Status;
    private JPanel StatusPanel;
    private JTextField TX1Text;
    private JTextField TX2Text;
    private JTextField TY1Text;
    private JTextField TY2Text;
    private JTextField TX12Text;
    private JTextField TY12Text;
    private JTextField txtTimer;
    private JCheckBox chkTimer;
    
    public void log(final String s) {
        this.Log.setText(String.valueOf(this.Log.getText()) + "\r\n" + s);
        this.sbDebugLog.append("\r\n" + s);
    }
    
    public void logDebug(final String s) {
        this.sbDebugLog.append("\r\n" + s);
    }
    
    private void status(final String s) {
        this.Status.setText(s);
    }
    
    public Chessbot() {
        this.isPointSet = false;
        this.gameEngine = null;
        this.txtMaxTime = new JTextField();
        this.txtDepth = new JTextField();
        this.txt960Row = new JTextField();
        this.chk960Row = new JCheckBox();
        this.pBestMoves = new JPanel();
        this.lblPonder = new JLabel();
        this.lblBest1Move = new JLabel();
        this.lblBest1Extra = new JLabel();
        this.lblBest2Move = new JLabel();
        this.lblBest2Extra = new JLabel();
        this.lblBest3Move = new JLabel();
        this.lblBest3Extra = new JLabel();
        this.lblBest4Move = new JLabel();
        this.lblBest4Extra = new JLabel();
        this.p1 = new JPanel();
        this.p2 = new JPanel();
        this.p3 = new JPanel();
        this.txtTrigger = new JTextField();
        this.txtPadding = new JTextField();
        this.sbDebugLog = new StringBuilder();
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                Chessbot.this.saveUIToSettings();
                Settings.save();
                if (Chessbot.this.engineBoard.getEngine() != null) {
                    Chessbot.this.engineBoard.getEngine().quit();
                }
            }
        });
        this.initComponents();
        ImageIcon icoApp = null;
        final URL urlJar = this.getClass().getResource("/icon.png");
        icoApp = ((urlJar == null) ? new ImageIcon("src/icon.png") : new ImageIcon(urlJar));
        this.setIconImage(icoApp.getImage());
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(this);
        Mouse.check();
        Screen.check();
        this.Board1 = new UIBoard();
        this.engineBoard = new EngineBoard();
        this.uiBoard = new UIBoard();
        this.Board1.setCode("B1");
        this.engineBoard.setCode("B2");
        this.uiBoard.setCode("B2");
        this.uiBoard.setMirror(this.Board1);
        (this.gameEngine = new Game(this.Board1, this, this.Status)).setBoard2(this.engineBoard);
        this.gameEngine.start();
        ((DefaultCaret)this.Log.getCaret()).setUpdatePolicy(2);
        final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.pack();
        this.setLocation((screenSize.width - this.getSize().width) / 2, screenSize.height - this.getSize().height - 50);
        this.pBestMoves.setMinimumSize(this.pBestMoves.getPreferredSize());
        this.p1.setMinimumSize(this.p1.getPreferredSize());
        this.p2.setMinimumSize(this.p2.getPreferredSize());
        this.updateUIFromSettings();
    }
    
    private void initComponents() {
        this.BGPanel = new JPanel();
        this.TX1Text = new JTextField();
        this.TY1Text = new JTextField();
        this.BX1Text = new JTextField();
        this.BY1Text = new JTextField();
        this.TX2Text = new JTextField();
        this.TY2Text = new JTextField();
        this.BX2Text = new JTextField();
        this.BY2Text = new JTextField();
        this.TX12Text = new JTextField();
        this.TY12Text = new JTextField();
        this.BX12Text = new JTextField();
        this.BY12Text = new JTextField();
        this.txtTimer = new JTextField();
        this.chkTimer = new JCheckBox();
        this.SetButton = new JButton();
        this.StartButton = new JButton();
        this.ResetButton = new JButton();
        this.DelayLabel = new JLabel();
        this.txtDelay = new JTextField();
        this.MouseDelayLabel = new JLabel();
        this.txtMouseDelayMax = new JTextField();
        this.txtMouseDelayMin = new JTextField();
        this.LoadButton = new JButton();
        this.SaveButton = new JButton();
        (this.chkDebug = new JCheckBox()).setMargin(new Insets(0, 4, 0, 4));
        (this.chkAnimation1 = new JCheckBox()).setMargin(new Insets(0, 4, 0, 4));
        (this.chkAnimationTrigger1 = new JCheckBox()).setMargin(new Insets(0, 4, 0, 4));
        (this.chkDeadMouse = new JCheckBox()).setMargin(new Insets(0, 4, 0, 4));
        this.StatusPanel = new JPanel();
        this.Status = new JLabel();
        this.LogScrollPane = new JScrollPane();
        this.Log = new JTextArea();
        this.chkTimer.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent e) {
                Chessbot.this.txtTimer.setEnabled(Chessbot.this.chkTimer.isSelected());
            }
        });
        this.txtTimer.setEnabled(this.chkTimer.isSelected());
        this.chkAnimationTrigger1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(final ChangeEvent e) {
                Chessbot.this.chkAnimation1.setEnabled(!Chessbot.this.chkAnimationTrigger1.isSelected());
            }
        });
        this.setDefaultCloseOperation(3);
        this.setTitle("Universal Chessbot Client v3.0.17 - x64 MEM");
        this.setAlwaysOnTop(true);
        this.setCursor(new Cursor(0));
        this.setName("Chessbot");
        this.setResizable(true);
        this.setMaximumSize(new Dimension(1024, 768));
        this.BGPanel.setBackground(new Color(51, 51, 51));
        this.SetButton.setBackground(new Color(51, 51, 51));
        this.SetButton.setFont(new Font("Georgia", 3, 12));
        this.SetButton.setText("Set Point");
        this.SetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                Chessbot.this.SetButtonActionPerformed(evt);
            }
        });
        this.StartButton.setBackground(new Color(51, 51, 51));
        this.StartButton.setFont(new Font("Georgia", 3, 12));
        this.StartButton.setText("Start F7");
        this.StartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                Chessbot.this.StartButtonActionPerformed(evt);
            }
        });
        this.ResetButton.setBackground(new Color(51, 51, 51));
        this.ResetButton.setFont(new Font("Georgia", 3, 12));
        this.ResetButton.setText("Reset F8");
        this.ResetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                Chessbot.this.reset();
            }
        });
        this.DelayLabel.setBackground(new Color(255, 0, 0));
        this.DelayLabel.setFont(new Font("Georgia", 3, 12));
        this.DelayLabel.setForeground(new Color(255, 0, 0));
        this.DelayLabel.setText("Animation Check Delay (ms)");
        this.txtDelay.setText("100");
        this.MouseDelayLabel.setBackground(new Color(255, 0, 0));
        this.MouseDelayLabel.setFont(new Font("Georgia", 3, 12));
        this.MouseDelayLabel.setForeground(new Color(255, 0, 0));
        this.MouseDelayLabel.setText("Mouse Delay (ms)");
        this.txtMouseDelayMin.setText("0");
        this.txtMouseDelayMax.setText("0");
        this.LoadButton.setBackground(new Color(51, 51, 51));
        this.LoadButton.setFont(new Font("Georgia", 3, 12));
        this.LoadButton.setText("Load");
        this.LoadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                Chessbot.this.LoadButtonActionPerformed(evt);
            }
        });
        this.SaveButton.setBackground(new Color(51, 51, 51));
        this.SaveButton.setFont(new Font("Georgia", 3, 12));
        this.SaveButton.setText("Save");
        this.SaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent evt) {
                Chessbot.this.SaveButtonActionPerformed(evt);
            }
        });
        this.chkAnimation1.setBackground(new Color(0, 0, 0));
        this.chkAnimation1.setForeground(new Color(0, 144, 255));
        this.chkAnimation1.setFont(new Font("Georgia", 3, 12));
        this.chkAnimation1.setText("Animations");
        this.chkAnimation1.setSelected(true);
        this.chkAnimation1.setEnabled(false);
        this.chkAnimationTrigger1.setBackground(new Color(0, 0, 0));
        this.chkAnimationTrigger1.setForeground(new Color(0, 144, 255));
        this.chkAnimationTrigger1.setFont(new Font("Georgia", 3, 12));
        this.chkAnimationTrigger1.setText("Trigger");
        this.chkAnimationTrigger1.setSelected(true);
        this.chkDeadMouse.setBackground(new Color(0, 0, 0));
        this.chkDeadMouse.setForeground(new Color(0, 144, 255));
        this.chkDeadMouse.setFont(new Font("Georgia", 3, 12));
        this.chkDeadMouse.setText("Dead Mouse");
        this.chkDeadMouse.setSelected(false);
        this.chkDebug.setBackground(new Color(0, 0, 0));
        this.chkDebug.setForeground(new Color(0, 144, 255));
        this.chkDebug.setFont(new Font("Georgia", 3, 12));
        this.chkDebug.setText("Moves/Debug");
        this.chkDebug.setSelected(false);
        final JPanel pMain = new JPanel();
        pMain.setBackground(Color.BLACK);
        final BoxLayout lMain = new BoxLayout(pMain, 0);
        pMain.setLayout(lMain);
        final BoxLayout l0 = new BoxLayout(this.pBestMoves, 1);
        final BoxLayout l2 = new BoxLayout(this.p1, 1);
        final BoxLayout l3 = new BoxLayout(this.p2, 1);
        final BoxLayout l4 = new BoxLayout(this.p3, 1);
        this.pBestMoves.setLayout(l0);
        this.p1.setLayout(l2);
        this.p2.setLayout(l3);
        this.p3.setLayout(l4);
        this.pBestMoves.setBackground(new Color(255, 199, 4));
        this.p1.setBackground(Color.BLACK);
        this.p2.setBackground(Color.BLACK);
        this.p3.setBackground(Color.BLACK);
        pMain.add(this.pBestMoves);
        pMain.add(this.p1);
        pMain.add(this.p2);
        pMain.add(this.p3);
        this.lblPonder.setBackground(new Color(92, 127, 255));
        this.lblPonder.setBackground(new Color(255, 199, 4));
        this.lblPonder.setFont(new Font("Tahoma", 3, 14));
        this.lblPonder.setForeground(Color.RED);
        this.lblPonder.setAlignmentX(0.5f);
        this.lblPonder.setPreferredSize(new Dimension(140, 20));
        this.lblPonder.setMaximumSize(new Dimension(140, 20));
        this.lblBest1Move.setBackground(new Color(255, 199, 4));
        this.lblBest1Move.setFont(new Font("Georgia", 3, 14));
        this.lblBest1Move.setForeground(Color.RED);
        this.lblBest1Move.setAlignmentX(0.5f);
        this.lblBest1Move.setPreferredSize(new Dimension(140, 20));
        this.lblBest1Move.setMaximumSize(new Dimension(140, 20));
        this.lblBest2Move.setBackground(new Color(255, 199, 4));
        this.lblBest2Move.setFont(new Font("Georgia", 3, 14));
        this.lblBest2Move.setForeground(Color.RED);
        this.lblBest2Move.setAlignmentX(0.5f);
        this.lblBest2Move.setPreferredSize(new Dimension(140, 20));
        this.lblBest2Move.setMaximumSize(new Dimension(140, 20));
        this.lblBest3Move.setBackground(new Color(255, 199, 4));
        this.lblBest3Move.setFont(new Font("Georgia", 3, 14));
        this.lblBest3Move.setForeground(Color.RED);
        this.lblBest3Move.setAlignmentX(0.5f);
        this.lblBest3Move.setPreferredSize(new Dimension(140, 20));
        this.lblBest3Move.setMaximumSize(new Dimension(140, 20));
        this.lblBest4Move.setBackground(new Color(255, 199, 4));
        this.lblBest4Move.setFont(new Font("Tahoma", 3, 14));
        this.lblBest4Move.setForeground(Color.RED);
        this.lblBest4Move.setAlignmentX(0.5f);
        this.lblBest4Move.setPreferredSize(new Dimension(140, 20));
        this.lblBest4Move.setMaximumSize(new Dimension(140, 20));
        for (final JLabel lbl : Arrays.asList(this.lblBest1Extra, this.lblBest2Extra, this.lblBest3Extra, this.lblBest4Extra)) {
            lbl.setBackground(new Color(255, 199, 4));
            lbl.setFont(new Font("Georgia", 1, 14));
            lbl.setForeground(Color.darkGray);
            lbl.setAlignmentX(0.5f);
            lbl.setPreferredSize(new Dimension(150, 20));
            lbl.setMaximumSize(new Dimension(150, 20));
        }
        final JPanel pManual = new JPanel();
        (this.chkManualMode = new JCheckBox("Manual Mode")).setOpaque(false);
        this.chkManualMode.setForeground(new Color(0, 0, 0));
        this.chkManualMode.setFont(new Font("Tahoma", 1, 12));
        this.chkManualMode.setSelected(false);
        this.chkManualMode.setAlignmentX(0.0f);
        (this.chkClick = new JCheckBox("Click Mode")).setOpaque(false);
        this.chkClick.setForeground(new Color(0, 0, 0));
        this.chkClick.setFont(new Font("Tahoma", 1, 12));
        this.chkClick.setSelected(false);
        this.chkClick.setAlignmentX(0.0f);
        pManual.add(this.chkClick);
        (this.chkBook = new JCheckBox("Book")).setOpaque(false);
        this.chkBook.setForeground(new Color(0, 0, 0));
        this.chkBook.setFont(new Font("Tahoma", 1, 12));
        this.chkBook.setSelected(false);
        this.chkBook.setAlignmentX(0.0f);
        this.chkBook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (Chessbot.this.engineBoard.getBook() == null) {
                    Chessbot.this.loadBookToEngine(false);
                }
            }
        });
        final JButton btnBook = new JButton("...");
        btnBook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                Chessbot.this.loadBook();
            }
        });
        pManual.add(this.chkBook);
        pManual.add(btnBook);
        pManual.setOpaque(false);
        this.pBestMoves.add(pManual);
        final JPanel pPonder = new JPanel();
        pPonder.add(new JLabel("Ponder Expected Move: "));
        pPonder.add(this.lblPonder);
        pPonder.setBackground(new Color(255, 199, 4));
        final JPanel pBestMove1 = new JPanel();
        ((FlowLayout)pBestMove1.getLayout()).setVgap(0);
        pBestMove1.add(this.lblBest1Move);
        pBestMove1.add(this.lblBest1Extra);
        pBestMove1.setBackground(new Color(255, 199, 4));
        final JPanel pBestMove2 = new JPanel();
        ((FlowLayout)pBestMove2.getLayout()).setVgap(0);
        pBestMove2.add(this.lblBest2Move);
        pBestMove2.add(this.lblBest2Extra);
        pBestMove2.setBackground(new Color(255, 199, 4));
        final JPanel pBestMove3 = new JPanel();
        ((FlowLayout)pBestMove3.getLayout()).setVgap(0);
        pBestMove3.add(this.lblBest3Move);
        pBestMove3.add(this.lblBest3Extra);
        pBestMove3.setBackground(new Color(255, 199, 4));
        final JPanel pBestMove4 = new JPanel();
        ((FlowLayout)pBestMove4.getLayout()).setVgap(0);
        pBestMove4.add(this.lblBest4Move);
        pBestMove4.add(this.lblBest4Extra);
        pBestMove4.setBackground(new Color(255, 199, 4));
        this.pBestMoves.add(pPonder);
        this.pBestMoves.add(pBestMove1);
        this.pBestMoves.add(pBestMove2);
        this.pBestMoves.add(pBestMove3);
        this.pBestMoves.add(pBestMove4);
        final JPanel pTop = new JPanel();
        ((FlowLayout)pTop.getLayout()).setVgap(0);
        this.p1.add(pTop);
        pTop.add(this.chkTimer);
        pTop.add(this.txtTimer);
        this.chk960Row.setOpaque(false);
        pTop.add(this.chk960Row);
        pTop.add(this.txt960Row);
        this.txt960Row.setColumns(8);
        final JPanel pBoard1 = new JPanel();
        ((FlowLayout)pBoard1.getLayout()).setVgap(0);
        final JPanel pBoard2 = new JPanel();
        ((FlowLayout)pBoard2.getLayout()).setVgap(0);
        final JPanel pBoard2Engine = new JPanel();
        ((FlowLayout)pBoard2Engine.getLayout()).setVgap(0);
        final JPanel pBoard2EngineParams = new JPanel();
        ((FlowLayout)pBoard2EngineParams.getLayout()).setVgap(0);
        final JPanel pBoard2UI = new JPanel();
        ((FlowLayout)pBoard2UI.getLayout()).setVgap(0);
        this.p1.setBackground(new Color(255, 199, 4));
        this.p1.add(pBoard1);
        this.p1.add(pBoard2);
        this.p1.add(pBoard2Engine);
        this.p1.add(pBoard2EngineParams);
        pTop.setBackground(new Color(0, 0, 0));
        pBoard1.setOpaque(false);
        pBoard1.setForeground(new Color(255, 199, 4));
        pBoard2.setOpaque(false);
        pBoard2.setForeground(new Color(255, 199, 4));
        pBoard2Engine.setOpaque(false);
        pBoard2Engine.setForeground(new Color(255, 199, 4));
        pBoard2EngineParams.setOpaque(false);
        pBoard2EngineParams.setForeground(new Color(255, 199, 4));
        pBoard2UI.setOpaque(false);
        pBoard2UI.setForeground(new Color(255, 199, 4));
        pBoard1.add(new JLabel("Board"));
        pBoard1.add(this.TX1Text);
        pBoard1.add(this.TY1Text);
        pBoard1.add(new JLabel("=>>"));
        pBoard1.add(this.BX1Text);
        pBoard1.add(this.BY1Text);
        pBoard2.add(new JLabel("Trig"));
        pBoard2.add(this.TX12Text);
        pBoard2.add(this.TY12Text);
        pBoard2.add(new JLabel("=>>"));
        pBoard2.add(this.BX12Text);
        pBoard2.add(this.BY12Text);
        pBoard2UI.add(new JLabel("Source"));
        pBoard2UI.add(this.TX2Text);
        pBoard2UI.add(this.TY2Text);
        pBoard2UI.add(new JLabel("=>>"));
        pBoard2UI.add(this.BX2Text);
        pBoard2UI.add(this.BY2Text);
        final JButton btnEngine = new JButton("Engine Options...");
        btnEngine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                Chessbot.this.openEngineSettings();
            }
        });
        pBoard2Engine.add(btnEngine);
        pBoard2EngineParams.add(new JLabel("Max Time (ms)"));
        pBoard2EngineParams.add(this.txtMaxTime);
        this.txtMaxTime.setText("2000");
        this.txtMaxTime.addFocusListener(new FocusListener() {
            @Override
            public void focusLost(final FocusEvent e) {
                try {
                    Chessbot.this.engineBoard.setMoveTime(Integer.parseInt(Chessbot.this.txtMaxTime.getText()));
                }
                catch (NumberFormatException ex) {
                    Chessbot.this.txtMaxTime.setText(String.valueOf(Chessbot.this.engineBoard.getMoveTime()));
                }
            }
            
            @Override
            public void focusGained(final FocusEvent e) {
            }
        });
        pBoard2EngineParams.add(new JLabel("Depth"));
        pBoard2EngineParams.add(this.txtDepth);
        this.txtDepth.setText("5");
        this.txtDepth.addFocusListener(new FocusListener() {
            @Override
            public void focusLost(final FocusEvent e) {
                try {
                    Chessbot.this.engineBoard.setDepth(Integer.parseInt(Chessbot.this.txtDepth.getText()));
                }
                catch (NumberFormatException ex) {
                    Chessbot.this.txtDepth.setText(String.valueOf(Chessbot.this.engineBoard.getDepth()));
                }
            }
            
            @Override
            public void focusGained(final FocusEvent e) {
            }
        });
        this.TX1Text.setPreferredSize(new Dimension(40, 21));
        this.TY1Text.setPreferredSize(new Dimension(40, 21));
        this.BX1Text.setPreferredSize(new Dimension(40, 21));
        this.BY1Text.setPreferredSize(new Dimension(40, 21));
        this.TX2Text.setPreferredSize(new Dimension(40, 21));
        this.TY2Text.setPreferredSize(new Dimension(40, 21));
        this.BX2Text.setPreferredSize(new Dimension(40, 21));
        this.BY2Text.setPreferredSize(new Dimension(40, 21));
        this.TX12Text.setPreferredSize(new Dimension(40, 21));
        this.TY12Text.setPreferredSize(new Dimension(40, 21));
        this.BX12Text.setPreferredSize(new Dimension(40, 21));
        this.BY12Text.setPreferredSize(new Dimension(40, 21));
        this.txtMaxTime.setPreferredSize(new Dimension(60, 21));
        this.txtDepth.setPreferredSize(new Dimension(40, 21));
        this.txtTimer.setPreferredSize(new Dimension(70, 25));
        this.txtTimer.setFont(new Font("Tahoma", 1, 14));
        this.chkTimer.setBackground(Color.black);
        final JPanel pLoadSave = new JPanel();
        pLoadSave.setLayout(new FlowLayout(2));
        pLoadSave.setBackground(Color.BLACK);
        pLoadSave.setLayout(new GridLayout(1, 2));
        this.p1.add(pLoadSave);
        pLoadSave.add(this.LoadButton);
        pLoadSave.add(this.SaveButton);
        pLoadSave.setPreferredSize(new Dimension(225, 25));
        pLoadSave.setMaximumSize(new Dimension(225, 25));
        this.chkDeadMouse.setAlignmentX(0.0f);
        this.chkAnimation1.setAlignmentX(0.0f);
        this.chkAnimationTrigger1.setAlignmentX(0.0f);
        this.chkDebug.setAlignmentX(0.0f);
        this.p2.add(this.chkDeadMouse);
        final JPanel pTrigger = new JPanel();
        pTrigger.setAlignmentX(0.0f);
        pTrigger.setLayout(new FlowLayout(0, 0, 0));
        pTrigger.setOpaque(false);
        pTrigger.setBackground(Color.BLUE);
        pTrigger.add(this.chkAnimationTrigger1);
        this.txtTrigger.setColumns(5);
        pTrigger.add(this.txtTrigger);
        final JLabel lblTrigger = new JLabel("ms");
        lblTrigger.setForeground(new Color(0, 144, 255));
        pTrigger.add(lblTrigger);
        this.p2.add(pTrigger);
        this.p2.add(this.chkAnimation1);
        this.p2.add(this.chkDebug);
        final JPanel pPadding = new JPanel();
        final JLabel lblPadding = new JLabel("Padding (px)");
        lblPadding.setFont(new Font("Georgia", 3, 12));
        lblPadding.setForeground(new Color(255, 0, 0));
        lblPadding.setOpaque(false);
        this.txtPadding.setText("8");
        pPadding.setLayout(new FlowLayout(0, 5, 0));
        pPadding.setAlignmentX(0.0f);
        pPadding.setBackground(Color.BLACK);
        pPadding.add(this.txtPadding);
        pPadding.add(lblPadding);
        this.p2.add(pPadding);
        final JPanel pDelay = new JPanel();
        pDelay.setLayout(new FlowLayout(0, 5, 0));
        pDelay.setAlignmentX(0.0f);
        pDelay.setBackground(Color.BLACK);
        pDelay.add(this.txtDelay);
        pDelay.add(this.DelayLabel);
        this.p2.add(pDelay);
        final JPanel pMouseDelay = new JPanel();
        pMouseDelay.setLayout(new FlowLayout(0, 5, 0));
        pMouseDelay.setAlignmentX(0.0f);
        pMouseDelay.setBackground(Color.BLACK);
        pMouseDelay.add(this.txtMouseDelayMin);
        pMouseDelay.add(this.txtMouseDelayMax);
        pMouseDelay.add(this.MouseDelayLabel);
        this.p2.add(pMouseDelay);
        final JPanel pSetStart = new JPanel();
        pSetStart.setAlignmentX(0.0f);
        pSetStart.setBackground(Color.BLACK);
        pSetStart.setLayout(new GridLayout(1, 3));
        this.p2.add(pSetStart);
        pSetStart.add(this.SetButton);
        pSetStart.add(this.StartButton);
        pSetStart.add(this.ResetButton);
        pSetStart.setMaximumSize(new Dimension(280, 20));
        this.txtPadding.setMaximumSize(new Dimension(36, 20));
        this.txtPadding.setPreferredSize(new Dimension(36, 20));
        this.txtDelay.setMaximumSize(new Dimension(36, 20));
        this.txtMouseDelayMin.setMaximumSize(new Dimension(36, 20));
        this.txtMouseDelayMax.setMaximumSize(new Dimension(36, 20));
        this.txtDelay.setPreferredSize(new Dimension(36, 20));
        this.txtMouseDelayMin.setPreferredSize(new Dimension(36, 20));
        this.txtMouseDelayMax.setPreferredSize(new Dimension(36, 20));
        this.StartButton.setMaximumSize(this.SetButton.getMaximumSize());
        this.ResetButton.setMaximumSize(this.SetButton.getMaximumSize());
        final JButton btnExportDebugLog = new JButton("Export Debug Log...");
        btnExportDebugLog.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                Chessbot.this.exportDebugLog();
            }
        });
        final JPanel pExport = new JPanel();
        pExport.setOpaque(false);
        pExport.setLayout(new FlowLayout(0, 0, 0));
        pExport.setPreferredSize(new Dimension(400, 25));
        pExport.setMaximumSize(new Dimension(400, 25));
        pExport.add(btnExportDebugLog);
        this.p3.add(pExport);
        this.p3.add(this.LogScrollPane);
        this.p3.add(this.StatusPanel);
        this.getContentPane().add(pMain);
        this.StatusPanel.setBackground(new Color(0, 0, 0));
        this.StatusPanel.setPreferredSize(new Dimension(400, 25));
        this.StatusPanel.setMaximumSize(new Dimension(400, 25));
        this.Status.setBackground(new Color(255, 153, 0));
        this.Status.setFont(new Font("Georgia", 0, 13));
        this.Status.setForeground(new Color(255, 213, 7));
        this.Status.setText("Hover on each border corner (top-left and bottom-right) and hit F5.");
        final GroupLayout StatusPanelLayout = new GroupLayout(this.StatusPanel);
        this.StatusPanel.setLayout(StatusPanelLayout);
        StatusPanelLayout.setHorizontalGroup(StatusPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(StatusPanelLayout.createSequentialGroup().addContainerGap().addComponent(this.Status, -1, 353, 32767).addContainerGap()));
        StatusPanelLayout.setVerticalGroup(StatusPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.Status, -1, 17, 32767));
        this.Log.setColumns(16);
        this.Log.setFont(new Font("Georgia", 2, 12));
        this.Log.setRows(6);
        this.Log.setText("## Game Log ##\r\n## PLEASE REPORT ALL GLITCHES TO 19911225q@gmail.com ##\r\n## BE ETHICAL ##");
        this.sbDebugLog = new StringBuilder(this.Log.getText());
        this.LogScrollPane.setViewportView(this.Log);
        final GroupLayout BGPanelLayout = new GroupLayout(this.BGPanel);
        this.BGPanel.setLayout(BGPanelLayout);
        this.pack();
    }
    
    protected void loadBook() {
        final JFileChooser FileChooser = new JFileChooser();
        final FileFilter Filter2 = new FileFilter() {
            @Override
            public boolean accept(final File file) {
                return file.getName().endsWith(".abk") || file.isDirectory();
            }
            
            @Override
            public String getDescription() {
                return "Arena Book Files (*.abk)";
            }
        };
        FileChooser.setFileFilter(Filter2);
        FileChooser.setCurrentDirectory(new File("."));
        final int actionDialog = FileChooser.showSaveDialog(this);
        if (actionDialog == 0) {
            this.chkBook.setSelected(true);
            final File fl = FileChooser.getSelectedFile();
            Settings.set("Book.Path", fl.getAbsolutePath());
            this.loadBookToEngine(true);
        }
    }
    
    private void loadBookToEngine(final boolean force) {
        if (!force && !this.isUseBook()) {
            return;
        }
        final Thread t = new Thread() {
            @Override
            public void run() {
                Chessbot.this.engineBoard.loadBook(new File(Settings.get("Book.Path")));
            }
        };
        t.setPriority(1);
        t.start();
    }
    
    protected void exportDebugLog() {
        final JFileChooser FileChooser = new JFileChooser();
        final FileFilter Filter2 = new FileFilter() {
            @Override
            public boolean accept(final File file) {
                final String filename = file.getName();
                return filename.endsWith(".txt");
            }
            
            @Override
            public String getDescription() {
                return "*.txt";
            }
        };
        FileChooser.setFileFilter(Filter2);
        FileChooser.setCurrentDirectory(new File("."));
        final int actionDialog = FileChooser.showSaveDialog(this);
        if (actionDialog == 0) {
            File saveTo = FileChooser.getSelectedFile();
            final String filename = saveTo.getAbsolutePath();
            if (!filename.endsWith(".txt")) {
                saveTo = new File(String.valueOf(filename) + ".txt");
            }
            try {
                final PrintWriter out = new PrintWriter(saveTo);
                out.println("## " + Chessbot.fDateFormat.format(new Date()) + " ##");
                out.println(this.sbDebugLog.toString());
                out.close();
            }
            catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void SetButtonActionPerformed(final ActionEvent evt) {
        this.updatePoint();
    }
    
    private void StartButtonActionPerformed(final ActionEvent evt) {
        this.toggleGameRun();
    }
    
    private void updatePoint() {
        try {
            final int TX1 = Integer.parseInt(this.TX1Text.getText());
            final int TY1 = Integer.parseInt(this.TY1Text.getText());
            final int BX1 = Integer.parseInt(this.BX1Text.getText());
            final int BY1 = Integer.parseInt(this.BY1Text.getText());
            final int TX2 = Integer.parseInt(this.TX12Text.getText());
            final int TY2 = Integer.parseInt(this.TY12Text.getText());
            final int BX2 = Integer.parseInt(this.BX12Text.getText());
            final int BY2 = Integer.parseInt(this.BY12Text.getText());
            if (this.TX2Text.getText().length() > 0) {
                final int TX3 = Integer.parseInt(this.TX2Text.getText());
                final int TY3 = Integer.parseInt(this.TY2Text.getText());
                final int BX3 = Integer.parseInt(this.BX2Text.getText());
                final int BY3 = Integer.parseInt(this.BY2Text.getText());
                this.uiBoard.setArea(TX3, TY3, BX3 - TX3, BY3 - TY3, 0, 0, 0, 0);
                this.gameEngine.setBoard2(this.uiBoard);
                this.log("Set Point : (" + TX1 + "," + TY1 + ") (" + BX1 + "," + BY1 + ") vs (" + TX3 + "," + TY3 + ") (" + BX3 + "," + BY3 + ").");
            }
            else {
                this.gameEngine.setBoard2(this.engineBoard);
                this.log("Set Point : (" + TX1 + "," + TY1 + ") (" + BX1 + "," + BY1 + ") vs Engine.");
            }
            if (this.Board1 instanceof UIBoard) {
                ((UIBoard)this.Board1).setArea(TX1, TY1, BX1 - TX1, BY1 - TY1, TX2, TY2, BX2 - TX2, BY2 - TY2);
            }
            this.isPointSet = true;
            this.status("Click 'Start' or hit F7 to start the Game.");
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log("Set Point ERROR!!");
        }
    }
    
    private void toggleGameRun() {
        if (!this.isPointSet) {
            this.log("Start ERROR!! : Point Not Set");
            return;
        }
        try {
            if (this.gameEngine.isRunning()) {
                this.stopGame();
            }
            else {
                this.startGame();
            }
        }
        catch (Exception ex) {}
    }
    
    public void startGame() {
        this.Log.setText("#### Game Log ####");
        this.sbDebugLog = new StringBuilder(this.Log.getText());
        this.StartButton.setText("Stop F6");
        this.status("Game started. Click F6 to Stop");
        this.BGPanel.setBackground(new Color(255, 0, 13));
        int timerSeconds = 0;
        final String timer = this.txtTimer.getText();
        final Matcher m = Chessbot.PAT_TIMER.matcher(timer);
        timerSeconds = (m.matches() ? (Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(3))) : 300);
        Settings.set("Timer", this.formatSeconds(timerSeconds));
        this.txtTimer.setEditable(false);
        ((UIBoard)this.Board1).initGame();
        this.gameEngine.setTimerSeconds(timerSeconds);
        this.gameEngine.setRunning(true);
    }
    
    public String formatSeconds(final int secs) {
        return String.valueOf(secs / 60) + ":" + Chessbot.f2.format(secs % 60);
    }
    
    public void stopGame() {
        this.StartButton.setText("Start F7");
        this.status("Bot stopped. Click F8 to start a new match or F7 to resume the current one.");
        this.BGPanel.setBackground(new Color(51, 51, 51));
        this.gameEngine.setRunning(false);
        this.txtTimer.setEditable(true);
    }
    
    private void SaveButtonActionPerformed(final ActionEvent evt) {
        final JFileChooser FileChooser = new JFileChooser();
        final FileFilter Filter2 = new FileFilter() {
            @Override
            public boolean accept(final File file) {
                final String filename = file.getName();
                return filename.endsWith(".cbt");
            }
            
            @Override
            public String getDescription() {
                return "*.cbt";
            }
        };
        FileChooser.setFileFilter(Filter2);
        FileChooser.setCurrentDirectory(new File("./"));
        final int actionDialog = FileChooser.showSaveDialog(this);
        if (actionDialog == 0) {
            File saveTo = FileChooser.getSelectedFile();
            final String filename = saveTo.getName();
            if (!filename.endsWith(".cbt")) {
                saveTo = new File(String.valueOf(filename) + ".cbt");
            }
            this.saveUIToSettings();
            Settings.save(saveTo);
        }
    }
    
    private void saveUIToSettings() {
        String coords = "";
        coords = String.valueOf(coords) + this.TX1Text.getText() + ":";
        coords = String.valueOf(coords) + this.TY1Text.getText() + ":";
        coords = String.valueOf(coords) + this.BX1Text.getText() + ":";
        coords = String.valueOf(coords) + this.BY1Text.getText() + ":";
        coords = String.valueOf(coords) + this.TX12Text.getText() + ":";
        coords = String.valueOf(coords) + this.TY12Text.getText() + ":";
        coords = String.valueOf(coords) + this.BX12Text.getText() + ":";
        coords = String.valueOf(coords) + this.BY12Text.getText() + ":";
        Settings.set("coordinates", coords);
        Settings.set("Animation1.Enabled", this.chkAnimation1.isSelected() ? "true" : "false");
        Settings.set("AnimationTrigger1.Enabled", this.chkAnimationTrigger1.isSelected() ? "true" : "false");
        Settings.set("DeadMouse.Enabled", this.chkDeadMouse.isSelected() ? "true" : "false");
        Settings.set("Debug.Enabled", this.chkDebug.isSelected() ? "true" : "false");
    }
    
    private void LoadButtonActionPerformed(final ActionEvent evt) {
        final JFileChooser FileChooser = new JFileChooser();
        final FileFilter Filter2 = new FileFilter() {
            @Override
            public boolean accept(final File file) {
                final String filename = file.getName();
                return filename.endsWith(".cbt");
            }
            
            @Override
            public String getDescription() {
                return "*.cbt";
            }
        };
        FileChooser.setFileFilter(Filter2);
        FileChooser.setCurrentDirectory(new File("./"));
        final int actionDialog = FileChooser.showOpenDialog(this);
        if (actionDialog == 0) {
            final File loadFrom = FileChooser.getSelectedFile();
            Settings.load(loadFrom);
            this.updateUIFromSettings();
        }
    }
    
    private void updateUIFromSettings() {
        final String coords = Settings.get("coordinates");
        if (coords != null) {
            try {
                final String[] dataList = coords.split(":");
                this.TX1Text.setText(dataList[0]);
                this.TY1Text.setText(dataList[1]);
                this.BX1Text.setText(dataList[2]);
                this.BY1Text.setText(dataList[3]);
                this.TX12Text.setText(dataList[4]);
                this.TY12Text.setText(dataList[5]);
                this.BX12Text.setText(dataList[6]);
                this.BY12Text.setText(dataList[7]);
                this.txtDelay.requestFocus();
                this.updatePoint();
            }
            catch (Exception ex) {}
        }
        try {
            this.txtTimer.setText(Settings.get("Timer", "5:00"));
            this.chkAnimation1.setSelected("true".equals(Settings.get("Animation1.Enabled")));
            this.chkAnimationTrigger1.setSelected("true".equals(Settings.get("AnimationTrigger1.Enabled")));
            this.chkDeadMouse.setSelected("true".equals(Settings.get("DeadMouse.Enabled")));
            this.chkDebug.setSelected("true".equals(Settings.get("Debug.Enabled")));
        }
        catch (Exception ex2) {}
    }
    
    private void openEngineSettings() {
        (this.dlgEngineConfig = new EngineConfigDialog(this.engineBoard)).pack();
        this.dlgEngineConfig.setVisible(true);
    }
    
    @Override
    public boolean dispatchKeyEvent(final KeyEvent e) {
        if (e.getID() != 402) {
            return false;
        }
        if (e.getKeyCode() == 115) {
            this.openEngineSettings();
        }
        if (e.getKeyCode() == 116) {
            if (this.TX1Text.getText().length() == 0) {
                this.TX1Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getX()));
                this.TY1Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getY()));
            }
            else if (this.BX1Text.getText().length() == 0) {
                this.BX1Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getX()));
                this.BY1Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getY()));
            }
            else if (this.TX12Text.getText().length() == 0) {
                this.TX12Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getX()));
                this.TY12Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getY()));
            }
            else if (this.BX12Text.getText().length() == 0) {
                this.BX12Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getX()));
                this.BY12Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getY()));
                this.updatePoint();
            }
            else {
                this.TX1Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getX()));
                this.TY1Text.setText(String.valueOf((int)Mouse.getCurrentPoint().getY()));
                this.BX1Text.setText("");
                this.BY1Text.setText("");
                this.TX12Text.setText("");
                this.TY12Text.setText("");
                this.BX12Text.setText("");
                this.BY12Text.setText("");
                this.TX2Text.setText("");
                this.TY2Text.setText("");
                this.BX2Text.setText("");
                this.BY2Text.setText("");
            }
            e.consume();
            return true;
        }
        if (e.getKeyCode() == 117) {
            this.stopGame();
            e.consume();
            return true;
        }
        if (e.getKeyCode() == 118) {
            this.startGame();
            e.consume();
            return true;
        }
        if (e.getKeyCode() == 119) {
            this.reset();
            e.consume();
            return true;
        }
        if (e.getKeyCode() == 120) {
            this.gameEngine.manualTurn();
            e.consume();
            return true;
        }
        if (e.getKeyCode() == 121) {
            this.gameEngine.dumpBoards();
            e.consume();
            return true;
        }
        return false;
    }
    
    private void reset() {
        if (this.gameEngine.isRunning()) {
            this.stopGame();
        }
        this.status("Click 'Start' or hit F7 to start a new Game.");
        this.Log.setText("#### Boards flushed and log reset. ####");
        this.sbDebugLog = new StringBuilder(this.Log.getText());
        this.gameEngine.resetBoards();
        this.txtTimer.setText(Settings.get("Timer", "5:00"));
    }
    
    public int getDelay() {
        try {
            return Integer.parseInt(this.txtDelay.getText());
        }
        catch (NumberFormatException e) {
            return 100;
        }
    }
    
    public int getPadding() {
        try {
            return Integer.parseInt(this.txtPadding.getText());
        }
        catch (NumberFormatException e) {
            return 8;
        }
    }
    
    public int getMouseDelay() {
        int x0 = 1;
        int x2 = 100;
        try {
            x0 = Integer.parseInt(this.txtMouseDelayMin.getText());
            x2 = Integer.parseInt(this.txtMouseDelayMax.getText());
        }
        catch (NumberFormatException ex) {}
        x2 = Math.max(x0 + 1, x2);
        return x0 + (int)(Math.random() * (x2 - x0));
    }
    
    public boolean isAnimationEnabled(final Board board) {
        return board == this.Board1 && this.chkAnimation1.isSelected();
    }
    
    public boolean isAnimationTriggerEnabled(final Board board) {
        return board == this.Board1 && this.chkAnimationTrigger1.isSelected();
    }
    
    public int getAnimationTriggerTimer(final Board board) {
        try {
            if (board == this.Board1) {
                return Integer.parseInt(this.txtTrigger.getText().trim());
            }
            return 0;
        }
        catch (NumberFormatException e) {
            return 0;
        }
    }
    
    public boolean isDebugEnabled() {
        return this.chkDebug.isSelected();
    }
    
    public boolean isManualMode() {
        return this.chkManualMode.isSelected();
    }
    
    public boolean isDeadMouseEnabled() {
        return this.chkDeadMouse.isSelected();
    }
    
    public void updateClock(final int timerSeconds) {
        this.txtTimer.setText(this.formatSeconds(timerSeconds));
    }
    
    public boolean isTimerEnabled() {
        return this.chkTimer.isSelected();
    }
    
    public void setBestMove(final int idx, final String move, final String extra) {
        if (idx == 1) {
            this.lblBest1Move.setText(move);
            this.lblBest1Extra.setText(extra);
        }
        else if (idx == 2) {
            this.lblBest2Move.setText(move);
            this.lblBest2Extra.setText(extra);
        }
        else if (idx == 3) {
            this.lblBest3Move.setText(move);
            this.lblBest3Extra.setText(extra);
        }
        else if (idx == 4) {
            this.lblBest4Move.setText(move);
            this.lblBest4Extra.setText(extra);
        }
    }
    
    public void setPonder(final String ponder) {
        if (ponder == null) {
            this.lblPonder.setText("_ _ _");
        }
        else {
            this.lblPonder.setText(ponder);
        }
    }
    
    public void clearBestMoves() {
        this.lblBest1Move.setText("");
        this.lblBest1Extra.setText("");
        this.lblBest2Move.setText("");
        this.lblBest2Extra.setText("");
        this.lblBest3Move.setText("");
        this.lblBest3Extra.setText("");
        this.lblBest4Move.setText("");
        this.lblBest4Extra.setText("");
    }
    
    public String getStartPos() {
        if (!this.chk960Row.isSelected()) {
            return null;
        }
        final String pos = this.txt960Row.getText();
        if (this.validateStartPos(pos)) {
            this.txt960Row.setBackground(Color.WHITE);
            return pos;
        }
        if (pos.length() > 0 || this.engineBoard.getEngine().is960Enabled()) {
            this.txt960Row.setBackground(new Color(255, 200, 200));
        }
        else {
            this.txt960Row.setBackground(Color.WHITE);
        }
        return null;
    }
    
    public boolean validateStartPos(final String pos) {
        if (pos.length() != 8) {
            return false;
        }
        int k = 0;
        int n = 0;
        int r = 0;
        int q = 0;
        int b = 0;
        for (final char c : pos.toUpperCase().toCharArray()) {
            if (c == 'K') {
                ++k;
            }
            else if (c == 'N') {
                ++n;
            }
            else if (c == 'R') {
                ++r;
            }
            else if (c == 'Q') {
                ++q;
            }
            else if (c != 'B') {
                ++b;
            }
        }
        return k == 1 && q == 1 && b == 2 && n == 2 && r == 2;
    }
    
    public boolean isUseBook() {
        return this.chkBook.isSelected();
    }
    
    public boolean isClick() {
        return this.chkClick.isSelected();
    }
    
    static {
        fDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        Chessbot.PAT_TIMER = Pattern.compile("((\\d)++)\\:((\\d)++)");
        Chessbot.f2 = new DecimalFormat("00");
    }
}
