// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

public abstract class Board
{
    protected String code;
    protected Board mirror;
    protected Game game;
    private boolean thinking;
    
    public Board() {
        this.thinking = false;
    }
    
    public abstract void livingMouse();
    
    public abstract void ensureInitialized();
    
    public abstract void update();
    
    public abstract void reset();
    
    public abstract void dumpBoard();
    
    public final void move(final int from, final int to) {
        this.move(from, to, -1, -1);
    }
    
    public final void move(final int from, final int to, final int from2, final int to2) {
        this.thinking = true;
        if (this.mirror != null) {
            this.mirror.thinking = false;
        }
        this.moveImpl(from, to, from2, to2);
    }
    
    public abstract void moveImpl(final int p0, final int p1, final int p2, final int p3);
    
    public void setCode(final String code) {
        this.code = code;
    }
    
    public void setMirror(final Board mirror) {
        this.mirror = mirror;
    }
    
    public void setGame(final Game game) {
        this.game = game;
    }
    
    public abstract void move(final String p0, final String p1);
    
    public boolean isThinking() {
        return this.thinking;
    }
}
