// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.book.abk;

import com.malkav.chessbot.book.BookMove;
import java.util.Iterator;
import java.util.ArrayList;
import java.io.IOException;
import com.malkav.chessbot.book.Book;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class AbkBookReader
{
    private Map<Integer, AbkBookMove> moves;
    private int nextId;
    
    public AbkBookReader() {
        this.moves = new HashMap<Integer, AbkBookMove>();
        this.nextId = 900;
    }
    
    public static void main(final String[] args) throws IOException {
        final String flName = "Diffusion 1.0.5A2.abk";
        final long l0 = System.currentTimeMillis();
        final AbkBookReader reader = new AbkBookReader();
        final Book book = reader.read(new BufferedInputStream(new FileInputStream(new File(flName))));
        final long l2 = System.currentTimeMillis();
        System.out.println(String.valueOf(l2 - l0) + "ms");
    }
    
    public Book read(final InputStream in) throws IOException {
        if (in.read() != 3 || in.read() != 65 || in.read() != 66 || in.read() != 75) {
            throw new IllegalArgumentException("Not an ABK file");
        }
        final int movesOffset = this.readInt(in);
        this.skip(in, 4);
        final String title = this.readString(in);
        System.out.println(title);
        this.skip(in, 133 - (title.length() + 1) - 12);
        final String author = this.readString(in);
        System.out.println(author);
        this.skip(in, 218 - (author.length() + 1) - 133);
        final int numMoves = this.readInt(in);
        System.out.println(String.valueOf(numMoves) + " moves");
        this.skip(in, movesOffset - 218 - 4);
        for (int i = 0; i < numMoves; ++i) {
            this.readMove(in);
        }
        for (final AbkBookMove move : this.moves.values()) {
            move.updateNext(this.moves);
        }
        ArrayList<AbkBookMove> openings = new ArrayList<AbkBookMove>();
        for (final AbkBookMove abm : this.moves.values()) {
            Thread.yield();
            if (abm.isFirst()) {
                if (!abm.isValidOpening()) {
                    continue;
                }
                openings.add(abm);
            }
        }
        System.out.println("= Parsing done =");
        this.dumpMemInfo();
        this.moves.clear();
        this.moves = null;
        final Book book = new Book();
        final int size = openings.size();
        for (int j = size - 1; j >= 0; --j) {
            final AbkBookMove abm2 = openings.get(j);
            final BookMove move2 = abm2.buildBookMove();
            book.addOpening(move2);
            openings.remove(j);
            move2.pack();
        }
        System.out.println("= Book done =");
        this.dumpMemInfo();
        openings.clear();
        openings = null;
        System.out.println("= Cleaning done =");
        this.dumpMemInfo();
        System.out.println(String.valueOf(book.getOpenings().size()) + " openings in parsed Book!");
        return book;
    }
    
    private void dumpMemInfo() {
        this.dumpMemInfo0();
    }
    
    private void dumpMemInfo0() {
        final long free = Runtime.getRuntime().freeMemory() / 1048576L;
        final long total = Runtime.getRuntime().totalMemory() / 1048576L;
        final long max = Runtime.getRuntime().maxMemory() / 1048576L;
        System.out.println(" Mem: " + (total - free) + "/" + total + "/" + max + "MB");
    }
    
    private void skip(final InputStream in, int len) throws IOException {
        while (len > 0) {
            final long sk = in.skip(len);
            if (sk < 0L) {
                break;
            }
            len -= (int)sk;
        }
        while (len > 0) {
            in.read();
            --len;
        }
    }
    
    private void readMove(final InputStream in) throws IOException {
        final int fromPos = in.read();
        final int toPos = in.read();
        this.skip(in, 2);
        final int i1 = this.readInt(in);
        final int i2 = this.readInt(in);
        final int i3 = this.readInt(in);
        final int i4 = this.readInt(in);
        final int i5 = this.readInt(in);
        final int i6 = this.readInt(in);
        final int id = this.nextId++;
        final AbkBookMove mv = new AbkBookMove(id, (byte)fromPos, (byte)toPos, i5, i6);
        mv.setExtra(i1, i2, i3, i4);
        this.moves.put(mv.getId(), mv);
    }
    
    private String toNotation(final int pos) {
        final int col = pos % 8;
        final int row = pos / 8;
        return String.valueOf(String.valueOf((char)(65 + col))) + (row + 1);
    }
    
    private String readString(final InputStream in) throws IOException {
        final int len = in.read();
        final byte[] b = new byte[len];
        for (int i = 0; i < len; ++i) {
            b[i] = (byte)(in.read() & 0xFF);
        }
        return new String(b);
    }
    
    private int readInt(final InputStream in) throws IOException {
        return (in.read() & 0xFF) | (in.read() & 0xFF) << 8 | (in.read() & 0xFF) << 16 | (in.read() & 0xFF) << 24;
    }
}
