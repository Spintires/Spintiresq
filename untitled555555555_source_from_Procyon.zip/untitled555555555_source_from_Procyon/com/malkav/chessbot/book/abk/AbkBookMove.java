// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.book.abk;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import com.malkav.chessbot.book.BookMove;

public class AbkBookMove
{
    private int id;
    private byte from;
    private byte to;
    private int nextId;
    private int nextIdAlt;
    private AbkBookMove next;
    private AbkBookMove nextAlt;
    private AbkBookMove prev;
    private AbkBookMove prevAlt;
    private int numGames;
    private int bestForWhite;
    private int bestForBlack;
    private int i4;
    
    public AbkBookMove(final int id, final byte from, final byte to, final int nextId, final int nextIdAlt) {
        this.id = id;
        this.from = from;
        this.to = to;
        this.nextId = nextId;
        this.nextIdAlt = nextIdAlt;
    }
    
    public int getId() {
        return this.id;
    }
    
    public int getNextId() {
        return this.nextId;
    }
    
    public void setExtra(final int i1, final int i2, final int i3, final int i4) {
        this.numGames = i1;
        this.bestForWhite = i2;
        this.bestForBlack = i3;
        this.i4 = i4;
    }
    
    public String getNotation() {
        return String.valueOf(BookMove.toNotation(this.from)) + BookMove.toNotation(this.to);
    }
    
    @Override
    public String toString() {
        return "#" + this.id + ": " + this.getNotation() + " >> #" + this.nextId + "/#" + this.nextIdAlt + " x " + this.numGames + " | " + this.bestForWhite + "/" + this.bestForBlack + "/" + this.i4;
    }
    
    public void updateNext(final Map<Integer, AbkBookMove> moves) {
        if (this.nextId > -1) {
            this.next = moves.get(this.nextId);
            if (this.next != null) {
                this.next.prev = this;
            }
        }
        if (this.nextIdAlt > -1) {
            this.nextAlt = moves.get(this.nextIdAlt);
            if (this.nextAlt != null) {
                this.nextAlt.prevAlt = this;
            }
        }
    }
    
    public boolean isFirst() {
        if (this.prev != null) {
            return false;
        }
        if (this.prevAlt == null) {
            return true;
        }
        for (AbkBookMove p = this.prevAlt; p != null; p = p.prevAlt) {
            if (p.prev != null) {
                return false;
            }
        }
        return true;
    }
    
    public boolean isLast() {
        return this.nextId == -1;
    }
    
    public String getWholeGame() {
        final StringBuilder sb = new StringBuilder();
        if (this.isFirst()) {
            sb.append(this.getNotation());
            for (AbkBookMove mv = this.next; mv != null; mv = mv.next) {
                sb.append(" ").append(mv.getNotation());
            }
        }
        else {
            final ArrayList<AbkBookMove> moves = new ArrayList<AbkBookMove>();
            moves.add(this);
            for (AbkBookMove mv = this.prev; mv != null; mv = mv.getPreviousMove()) {
                if (mv.getNumGames() > 0) {
                    moves.add(mv);
                }
            }
            for (int i = moves.size() - 1; i >= 0; --i) {
                final AbkBookMove mv = moves.get(i);
                sb.append(mv.getNotation());
                if (i > 0) {
                    sb.append(" ");
                }
            }
        }
        return sb.toString();
    }
    
    private AbkBookMove getPreviousMove() {
        if (this.prev != null) {
            return this.prev;
        }
        if (this.prevAlt == null) {
            return null;
        }
        return this.prevAlt.getPreviousMove();
    }
    
    public int getNumGames() {
        return this.numGames;
    }
    
    public double getBlackBias() {
        if (this.bestForBlack + this.bestForWhite == 0) {
            return 0.5;
        }
        return this.bestForBlack / (double)(this.bestForBlack + this.bestForWhite);
    }
    
    public double getWhiteBias() {
        if (this.bestForBlack + this.bestForWhite == 0) {
            return 0.5;
        }
        return this.bestForWhite / (double)(this.bestForBlack + this.bestForWhite);
    }
    
    public AbkBookMove findMove(final List<String> gameMoves, final int offset) {
        if (offset >= gameMoves.size()) {
            return this;
        }
        final String nextMove = gameMoves.get(offset);
        final AbkBookMove move = this.getNextMove(nextMove);
        System.out.println(gameMoves + " @ " + offset + " found " + move + " looking for " + nextMove + " in " + this.getNotation() + " (x" + this.numGames + ")/" + this.getNextMoves());
        if (move == null) {
            return null;
        }
        return move.findMove(gameMoves, offset + 1);
    }
    
    public AbkBookMove getNextMove(final String move) {
        if (this.next != null) {
            if (move.equals(this.next.getNotation())) {
                return this.next;
            }
            for (AbkBookMove alt = this.next.nextAlt; alt != null; alt = alt.nextAlt) {
                if (move.equals(alt.getNotation())) {
                    return alt;
                }
            }
        }
        return null;
    }
    
    public AbkBookMove[] getNextMoves() {
        int moveCount = 0;
        if (this.next != null) {
            ++moveCount;
            for (AbkBookMove alt = this.next.nextAlt; alt != null; alt = alt.nextAlt) {
                ++moveCount;
            }
        }
        final AbkBookMove[] moves = new AbkBookMove[moveCount];
        int i = 0;
        if (this.next != null) {
            moves[i++] = this.next;
            for (AbkBookMove alt2 = this.next.nextAlt; alt2 != null; alt2 = alt2.nextAlt) {
                moves[i++] = alt2;
            }
        }
        return moves;
    }
    
    public BookMove buildBookMove() {
        final BookMove bm = new BookMove(this.from, this.to);
        bm.setGamesInformation(this.numGames, this.bestForWhite, this.bestForBlack);
        final AbkBookMove[] moves = this.getNextMoves();
        int idx = bm.getCurrentNextMovesSize();
        bm.increaseNextMovesBy(moves.length);
        for (final AbkBookMove next : moves) {
            bm.addNextMove(idx++, next.buildBookMove());
        }
        return bm;
    }
    
    public boolean isValidOpening() {
        final String fromTo = this.getNotation();
        final char c0 = fromTo.charAt(0);
        final char c2 = fromTo.charAt(2);
        final int r0 = fromTo.charAt(1) - '0';
        final int r2 = fromTo.charAt(3) - '0';
        return (r0 == 2 && (r2 == 3 || r2 == 4) && c0 == c2) || (fromTo.startsWith("b1") && (fromTo.endsWith("a3") || fromTo.endsWith("c3"))) || (fromTo.startsWith("g1") && (fromTo.endsWith("f3") || fromTo.endsWith("h3")));
    }
}
