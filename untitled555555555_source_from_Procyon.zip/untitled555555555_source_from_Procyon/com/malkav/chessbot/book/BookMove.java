// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.book;

import java.util.List;

public class BookMove
{
    private byte from;
    private byte to;
    private int numGames;
    private int bestForWhite;
    private int bestForBlack;
    private BookMove[] nextMoves;
    
    public BookMove(final byte from, final byte to) {
        this.from = from;
        this.to = to;
    }
    
    public void setGamesInformation(final int numGames, final int bestForWhite, final int bestForBlack) {
        this.numGames = numGames;
        this.bestForWhite = bestForWhite;
        this.bestForBlack = bestForBlack;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.getNotation()) + "(x" + this.numGames + " " + this.bestForWhite + "/" + this.bestForBlack + ")";
    }
    
    public String getNotation() {
        return String.valueOf(toNotation(this.from)) + toNotation(this.to);
    }
    
    public static String toNotation(final int pos) {
        final int col = pos % 8;
        final int row = pos / 8;
        return String.valueOf(String.valueOf((char)(97 + col))) + (row + 1);
    }
    
    public BookMove addNextMove(final int idx, final BookMove move) {
        final String smove = move.getNotation();
        final BookMove oldMove = this.getNextMove(smove);
        if (oldMove == null) {
            return this.nextMoves[idx] = move;
        }
        oldMove.merge(move);
        return oldMove;
    }
    
    public void pack() {
    }
    
    private BookMove getNextMove(final String smove) {
        for (final BookMove bm : this.nextMoves) {
            if (bm != null && smove.equals(bm.getNotation())) {
                return bm;
            }
        }
        return null;
    }
    
    public BookMove findMove(final List<String> gameMoves, final int offset) {
        if (offset >= gameMoves.size()) {
            return this;
        }
        final String nextMove = gameMoves.get(offset);
        final BookMove move = this.getNextMove(nextMove);
        if (move == null) {
            return null;
        }
        return move.findMove(gameMoves, offset + 1);
    }
    
    public void merge(final BookMove move) {
        this.numGames += move.numGames;
        this.bestForBlack += move.bestForBlack;
        this.bestForWhite += move.bestForWhite;
        int idx = this.getCurrentNextMovesSize();
        this.increaseNextMovesBy(move.nextMoves.length);
        for (final BookMove child : move.nextMoves) {
            this.addNextMove(idx++, child);
        }
    }
    
    public int getCurrentNextMovesSize() {
        if (this.nextMoves == null) {
            return 0;
        }
        return this.nextMoves.length;
    }
    
    public void increaseNextMovesBy(final int len) {
        final int curLen = this.getCurrentNextMovesSize();
        final BookMove[] newNextMoves = new BookMove[curLen + len];
        if (curLen > 0) {
            System.arraycopy(this.nextMoves, 0, newNextMoves, 0, curLen);
        }
        this.nextMoves = newNextMoves;
    }
    
    public BookMove[] getNextMoves() {
        return this.nextMoves;
    }
    
    public void dump() {
        this.dump(0);
    }
    
    public void dump(final int off) {
        System.out.print(this.getNotation());
        if (off > 3) {
            return;
        }
        for (int numNext = this.nextMoves.length, i = 0; i < numNext; ++i) {
            final BookMove move = this.nextMoves[i];
            if (move != null) {
                if (i == 0) {
                    System.out.print(" ");
                    move.dump(off + 1);
                }
                else {
                    System.out.println();
                    for (int j = 0; j < (off + 1) * 5; ++j) {
                        System.out.print(" ");
                    }
                    move.dump(off + 1);
                }
            }
        }
        if (off == 0) {
            System.out.println();
        }
    }
    
    public double getScore(final boolean forWhite) {
        final double t = this.bestForWhite + this.bestForBlack;
        final double score = (t == 0.0) ? 0.5 : (forWhite ? (this.bestForWhite / t) : (this.bestForBlack / t));
        if (score <= 0.4) {
            return 0.0;
        }
        return Math.log(this.numGames + 1) * score;
    }
}
