// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.book;

import java.util.Iterator;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Book
{
    private Map<String, BookMove> openings;
    
    public Book() {
        this.openings = new HashMap<String, BookMove>();
    }
    
    public void addOpening(final BookMove move) {
        final String smove = move.getNotation();
        final BookMove old = this.openings.get(smove);
        if (old != null) {
            old.merge(move);
        }
        else {
            this.openings.put(smove, move);
        }
    }
    
    public Map<String, BookMove> getOpenings() {
        return this.openings;
    }
    
    public BookMove pickNextMove(final String gameMoves) {
        final ArrayList<String> list = new ArrayList<String>();
        for (String move : gameMoves.split(" ")) {
            if ((move = move.trim()).length() > 0) {
                list.add(move);
            }
        }
        return this.pickNextMove(list);
    }
    
    public BookMove pickNextMove(final List<String> gameMoves) {
        final List<BookMove> moves = this.getNextMoves(gameMoves);
        if (moves == null || moves.size() == 0) {
            return null;
        }
        System.out.println("next moves: " + moves);
        final boolean forWhite = gameMoves.size() % 2 == 0;
        final double[] scores = new double[moves.size()];
        double totalScore = 0.0;
        for (int i = 0; i < moves.size(); ++i) {
            final BookMove move = moves.get(i);
            final double score = scores[i] = move.getScore(forWhite);
            totalScore += score;
        }
        if (totalScore == 0.0) {
            return null;
        }
        final double r = Math.random() * totalScore;
        double s = 0.0;
        for (int j = 0; j < moves.size(); ++j) {
            if (r < (s += scores[j])) {
                return moves.get(j);
            }
        }
        return null;
    }
    
    private List<BookMove> getNextMoves(final List<String> gameMoves) {
        if (gameMoves.size() == 0) {
            final ArrayList<BookMove> moves = new ArrayList<BookMove>();
            moves.addAll(this.openings.values());
            return moves;
        }
        final BookMove move = this.findMove(gameMoves);
        System.out.println(gameMoves + " - found move " + move);
        if (move != null) {
            final ArrayList<BookMove> nextMoves = new ArrayList<BookMove>();
            for (final BookMove bm : move.getNextMoves()) {
                if (bm != null) {
                    nextMoves.add(bm);
                }
            }
            return nextMoves;
        }
        return null;
    }
    
    private BookMove findMove(final List<String> gameMoves) {
        final BookMove opening = this.openings.get(gameMoves.get(0));
        if (opening != null) {
            return opening.findMove(gameMoves, 1);
        }
        return null;
    }
    
    public void dump() {
        for (final BookMove m : this.openings.values()) {
            m.dump();
        }
    }
}
