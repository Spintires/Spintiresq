// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot.win;

public class MouseHook
{
    private static native void init();
    
    private static native void shutdown();
    
    public static void main(final String[] args) throws Exception {
        init();
        Thread.sleep(5000L);
        shutdown();
    }
    
    public static void mouseDown() {
        System.out.println("mouseDown");
    }
    
    public static void mouseUp() {
        System.out.println("mouseUp");
    }
    
    static {
        System.loadLibrary("chessbot");
    }
}
