// 
// Decompiled by Procyon v0.5.36
// 

package com.malkav.chessbot;

import javax.swing.JLabel;

public class CursorInfo extends Thread
{
    private JLabel CurrentPosition;
    public boolean alive;
    
    @Override
    public void run() {
        try {
            while (this.alive) {
                this.CurrentPosition.setText("(" + (int)Mouse.getCurrentPoint().getX() + "," + (int)Mouse.getCurrentPoint().getY() + ") ");
                try {
                    Thread.sleep(50L);
                }
                catch (Exception ex) {}
            }
            this.CurrentPosition.setText("Point Set");
            Thread.sleep(1073741824L);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public CursorInfo(final JLabel CurrentPosition) {
        this.alive = true;
        this.CurrentPosition = CurrentPosition;
    }
}
